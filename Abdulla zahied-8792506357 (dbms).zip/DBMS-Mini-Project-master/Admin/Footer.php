 <div id="templatemo_content_bottom"></div>
    

	<div id="templatemo_footer">
        	<ul class="footer_menu">
                <li><a href="Index.php" class="current">Home</a></li>
                 <li><a href="User.php" class="current">Users</a></li>
                <li><a href="Station.php">Police Station</a></li>
                <li><a href="News.php">News</a></li>
                <li><a href="Tips.php">Safety Tips</a></li>
                <li><a href="Logout.php">Logout</a></li>
            </ul>
    
            Copyright © 2018 Crime Management System </div> 
	<!-- end of footer -->