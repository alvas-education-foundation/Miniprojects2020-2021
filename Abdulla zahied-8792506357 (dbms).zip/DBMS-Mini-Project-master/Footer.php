<div id="templatemo_content_bottom"></div>


<div id="templatemo_footer">
    <ul class="footer_menu">
        <li><a href="Index.php" class="current">Home</a></li>
        <li><a href="News.php">News</a></li>
        <li><a href="Tips.php">Safety Tips</a></li>
        <li><a href="Missing.php">Missing Persons</a></li>
        <li><a href="Wanted.php">Most Wanted</a></li>
        <li><a href="Register.php">Register</a></li>
        <li><a href="Contact.php">Contact Us</a></li>
    </ul>

    Made by Abhishek Thakur &copy; Abhishek_Thakur</div> 
<!-- end of footer -->