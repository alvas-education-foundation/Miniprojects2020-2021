<div id="templatemo_content_bottom"></div>


<div id="templatemo_footer">
    <ul class="footer_menu">
        <li><a href="Index.php" class="current">Home</a></li>
        <li><a href="Profile.php">Profile</a></li>
        <li><a href="Complains.php">Complaints</a></li>
        <li><a href="Missing.php">Missing Persons</a></li>
        <li><a href="Wanted.php">Most Wanted</a></li>
        <li><a href="Logout.php">Logout</a></li>
    </ul>

    Copyright © 2018 Crime Management System</div> 
<!-- end of footer -->