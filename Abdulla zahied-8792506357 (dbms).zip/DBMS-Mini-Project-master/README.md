# City-Without-Crime


Description :
  It is a simple website that manages online crime management system.
  Server Site Scripting done using PHP.
  For Database we used MYSQL.
  For Front-End we used HTML,CSS,JAVASCRIPT.
  
  
Project Url:
  Source : https://github.com/kumarcops/DBMS-Mini-Project
Name : Abhishek Thakur
