<!DOCTYPE html>
<html>
<head>
	<title>Service Request</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
	<body background="bg.jpg">
	<?php
$servername = "localhost";
$username = "AB";
$password = "kushi06";
$db="packers and movers";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT * FROM service_req";

$result = $conn->query($sql);
echo "<h3><u>Service Request</u></h3>";
echo "<table border='1'>
		<tr>
		<th>Agent_name</th>
		<th>Request Date</th>
		<th>Up Date</th>
		<th>From</th>
		<th>To</th>
		</tr>";
		if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
			echo "<tr>";
			echo "<td>".$row['Agent_name']."</td>";
			echo "<td>".$row['Req_date']."</td>";
			echo "<td>".$row['Up_date']."</td>";
			echo "<td>".$row['From_place']."</td>";
			echo "<td>".$row['To_place']."</td>";
			
			echo "</tr>";

			# code...
		}
		}
		echo "</table";
$conn->close();

?>

<h3><a href="admin.php"><div class="w3-display-bottommiddle w3-hide-small">Back to Menu</div></a></h3>

</body>
</html>