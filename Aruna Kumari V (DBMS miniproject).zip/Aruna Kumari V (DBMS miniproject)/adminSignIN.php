<!DOCTYPE html>
<html>
<head>
	<title>Admin SignIN</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="login">

	<body background="reg.jpg">
<center>
  <br><br><br><br><br>
  <h3><div class="w3-display-middle w3-hide-small">Admin SignIN here!</h3>
  	<table width="100%" border="0">
  
  <tr>
  
    <td valign="top"><div align="center">
    	<form name="form1" method="post" action="adminSignIN.php">
      <table width="200" border="0">
        <tr>
        	 <div class="input1">
                <label for="email">Email</label>
                <input type="email"  name="email" id="email" required="" placeholder="Email"><br/>
                </div>
                </tr>
                <br>
        <tr>
           <div class="input1">
                <label for="pass" >Password</label>
                <input type="password" name="pass" id="pass" required="" placeholder="Password"><br/></div>
        </tr>
        
        <tr>
          <td colspan=2 align=center class="errors">
		  <input name="submit" type="submit" id="submit" value="Login">		  </td>
        </tr>
        
      </table>
      
    </form></td>
  </tr>
</table>
<?php

$servername = "localhost";
$username = "AB";
$password = "kushi06";
$db="packers and movers";

//Create connection
$conn = new mysqli($servername, $username, $password, $db);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
 
if(isset($_POST['email']))
{
    $uname=$_POST['email'];
    $pass=$_POST['pass'];

  
    $sql="SELECT * FROM `admin` WHERE Email='".$uname."' AND Password='".$pass."' limit 1 ";
    
    $result=mysqli_query($conn,$sql);
   
    if(mysqli_num_rows($result)==1)
    {
       $_SESSION['username']=$uname;
       $_SESSION['success']="you are now logged in";
       header('Location:admin.php');
    }
    /*if(isset($_POST['submit'])&& !empty($_POST['SUBMIT'])){
        include 'userhome.php';
    }*/
    else
    {
        echo '<script type="text/javascript">alert("invalid username/password")</script>';
        /*include 'adminSignIN.php'; */  

         }
}

?>

</body>
</html>