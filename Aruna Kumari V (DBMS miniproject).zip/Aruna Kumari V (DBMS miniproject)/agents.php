<!DOCTYPE html>
<html>
<head>
	<title>Agents Registration</title>
	
</head>
<body>
	<br><br><br>
	<center><p>Create an account<p></center>
<br><br>
	<center>
	<form action="agr.php" method="POST">
		 <fieldset>
    <legend>Agent information:</legend>
		Agent Name:<input type="text" placeholder="Enter Agent name" name="Name" required=" "><br>
		<br>
		Address:<input type="text" placeholder="Enter Address" name="Address" required="">
		<br><br>
		City:<input type="text" placeholder="Enter City" name="City" required=" ">
		<br><br>
		State:<input type="text" placeholder="Enter State" name="State" required=" ">
		<br><br>
		Pincode:<input type="num" placeholder="Enter Pincode" name="Pincode" required=" ">
		<br><br>
		Contact:<input type="num" placeholder="Contact" name="Contact" required=" ">
		<br><br>
		Email ID:<input type="email" placeholder="Enter Email Address" name="Email" required=" ">
		<br><br>
		Services:<input type="text" placeholder="Services" name="Services" required=" ">
		<br><br>
		<input type="submit" name="submit">
		<input type="reset" name="Cancel">
</fieldset>
</form>
</center>
</body>
</html>

