<!DOCTYPE html>
<html>
<head>
	<title>Agents Confirmation</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
	<body background="agt.jpg">
	
	<br>
	<div class="w3-container">
		<h3><div class="w3-display-middle w3-hide-small">Registered successfully!</h3>
	<h3><a href="project.php"><div class="w3-display-bottommiddle w3-hide-small">Back to Home</div></a></h3>
	</div>

<?php
	$Name=$_POST['Name'];
	$Address=$_POST['Address'];
	$City=$_POST['City'];
	$State=$_POST['State'];
	$Pincode=$_POST['Pincode'];
	$Contact=$_POST['Contact'];
	$Email=$_POST['Email'];
	$Services=$_POST['Services'];

$servername = "localhost";
$username = "AB";
$password = "kushi06";
$db="packers and movers";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$query="insert into agents(Agents_name,Address,City,State,Pincode,Contact,Email,Services) values('$Name','$Address','$City','$State','$Pincode','$Contact','$Email','$Services')";
if ($conn->query($query) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}
$conn->close();

?>
</body>
</html>