<!DOCTYPE html>
<html>
<head>
	<title>Create Account</title>
<meta name="viewport" content="width=50, initial-scale=1">
<style>
/* Style all input fields */
input {
    width: 20%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 10px;
}

/* Style the submit button */
input[type=submit] {
    background-color: #4CAF50;
    color: white;
}

/* Style the container for inputs */
.container {
    background-color: #f1f1f1;
    padding: 20px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
    color: green;
}

.valid:before {
    position: relative;
    left: -35px;
    content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
    color: red;
}

.invalid:before {
    position: relative;
    left: -35px;
    content: "✖";
}
</style>
</head>


<body>
	<br><br><br>
	<center><p>Create an account<p></center>
<br><br>
	<center>
	<form action="pw.php" method="POST">
		 <fieldset>
    <legend>Personal information:</legend>
		Name:<input type="text" placeholder="Enter Name" name="Name" required=" "><br>
		<br>
		Email:<input type="email" placeholder="Enter Email" name="Email" required=" ">
		<br><br>
		Address:<input type="text" placeholder="Enter Address" name="Address" required=" ">
		<br><br>
		Contact num:<input type="num" placeholder="Contact" name="Contact" required=" ">
		<br><br>
		Gender:
		<select>
			<option value="Gender">Male</option>
			<option value="Gender">Female</option>
			<option value="Gender">Others</option>
		</select>
		<br><br>
		<input type="submit" name="submit">
		<input type="reset" name="Cancel">
	</form>
</fieldset>
</center>
</body>
</html>