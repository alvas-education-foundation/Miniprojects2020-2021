<!DOCTYPE html>
<html>
<head>
	<title>Service Types</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

.navbar {
  width: 100%;
  background-color: #555;
  overflow: auto;
}

.navbar a {
  float: left;
  padding: 0.5px;
  color: white;
  text-decoration: none;
  font-size: 19px;
}

.navbar a:hover {
  background-color: #000;
}

.active {
  background-color: #4CAF50;
}

@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
  }
}
</style>

<style>
.mySlides {display:none;}
</style>

<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 5px;
}

.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 400px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 10px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 6px 10px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #444;
  color: white;
}

.fa {font-size:50px;}

</style>

<script>
function openhome() {
    location.replace("project.php");
}
</script>

<script>
function openReg() {
    location.replace("housing.php");
}
</script>
</head>

<body>
  <div class="navbar">
    <a class="active" href="project.php"><i class="fa fa-fw fa-home"></i> Home</a> 
  </div>

<br><br><br><br>
<center>
    <div class="w3-content w3-section" style="max-width:1000px">
  <img class="mySlides" src="imgs1.jpg" style="width:100%">
  <img class="mySlides" src="imgs2.jpg" style="width:100%">
  <img class="mySlides" src="imgs3.jpg" style="width:100%">
  <img class="mySlides" src="imgs4.jpg" style="width:100%">
  <img class="mySlides" src="imgs5.jpg" style="width:100%">
  <img class="mySlides" src="imgs6.jpg" style="width:100%">
</div>
  </center>


<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 4000); // Change image every 4 seconds
}
</script>

<br><br><br>
<div class="row">
  <div class="column">
    <div class="card">
      <p><i class="fa fa-home"></i></p>
      <h3>Housing</h3>
      <button onclick="openReg()">Housing</button>

    </div>
  </div>
  <div class="column">
    <div class="card">
      <p><i class="fa fa-user"></i></p>
      <h3>Office Shifting</h3>
      <button onclick="openReg()">Office Shifting</button>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <p><i class="fa fa-automobile"></i></p>
      <h3>Vehicle</h3>
      <button onclick="openReg()">Vehicle</button>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <p><i class="fa fa-table"></i></p>
      <h3>Furniture</h3>
      <button onclick="openReg()">Furniture</button>
    </div>
  </div>
</div>


</body>
</html>

