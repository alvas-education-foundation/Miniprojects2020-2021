<!DOCTYPE html>
<html>
<head>
	<title>User Register Confirmation</title>
<style>
.button {
  display: inline-block;
  border-radius: 1px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 15px;
  padding: 10px;
  width: 75px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 20px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
<style>
.right {
    position: absolute;
    right: 0px;
    width: 300px;
    border: 2px solid #73AD21;
    padding: 20px;
}
</style>
<script>
	function openpage() {
		location.replace("opt.php");
	}
</script>
</head>
<body>
	<body background="register.jpg">
	<br><br><br><br><br>
<div class="right">
	<p><h3><b>your request has been registered!</b></h3></p>
		<?php
  	$a=$_POST['Username'];
		echo "Username:$a";
		?>
		<br><br>
		<?php
		$b=$_POST['psw'];
		echo "Password:$b";
		?>
	<br><br><br>
	<button class="button" style="vertical-align:middle" onclick="openpage()"><span>Next </span></button>
</div>
</body>
</html>
	<?php
  $Username=$_POST['Username'];
  $Password=$_POST['psw'];

$servername = "localhost";
$username = "AB";
$password = "kushi06";
$db="packers and movers";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$query="insert into password (username,password) values('$Username','$Password')";
if ($conn->query($query) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $query . "<br>" . $conn->error;
}
$conn->close();

?>

</body>
</html>