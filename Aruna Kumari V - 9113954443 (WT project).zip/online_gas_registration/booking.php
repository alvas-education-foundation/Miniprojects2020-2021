<?php
session_start();
include_once 'connections.php';
$uname = $_SESSION['name'];
$result = mysqli_query($conn,"select Amount from users Where Name='".$uname."'");
if( $result->num_rows >=0)
{	 
	while($row = $result->fetch_assoc())
	{
		if($row['Amount']>=850)
		{
	mysqli_query($conn,"UPDATE users SET Amount=Amount-850 WHERE Name ='" . $uname . "'");
	echo "<center>";
	echo "<h2><img src='smile.jpg'>Booking is done successfully</img></h2>";
	echo "<a href='receipt.php?&name=$uname'>Print RECEIPT</a>";
	echo "</center>";
}
else{
	echo "<script>alert('Low Balance');</script>";
	echo "<script>window.location.href='homepage.php';</script>";
}
}}
?>

