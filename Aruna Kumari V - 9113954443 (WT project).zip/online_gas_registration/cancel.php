<html>
<body>
<center>
  <br><br><br><br><br>
  <h2>Cancel Account</h2>
  <form method='post' action='cancel_user.php'>
   <table>
        <tr>
                <label for="name">Username</label>
                <input type="text"  name="name" id="name" required="" placeholder="Username"><br/>
                </tr>
                <br>
        <tr>
                <label for="pass" >Password</label>
                <input type="password" name="pass" id="pass" required="" placeholder="Password"><br/>
        </tr>
        
        <tr>
          <td colspan=2 align=center>
      <input name="submit" type="submit" id="submit" value="Cancel"></td></tr>
	  <br>
      </table>
	  </form>

<a href='homepage.php'>Back to home</a></td>
</body>
</html>