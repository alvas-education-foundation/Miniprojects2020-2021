<html>
<style>
body{
	 background-image: url('bck2.jpg');
	 background-size: cover;
}
</style>
<body>
<?php
include_once 'connections.php';

if(isset($_POST['name']))
{
    $uname=$_POST['name'];
    $pass=$_POST['pass'];
	$sql="SELECT * FROM `users` WHERE Name='".$uname."' AND Password='".$pass."' limit 1 ";
    
    $result=mysqli_query($conn,$sql);
   
    if(mysqli_num_rows($result)==1)
    {
       mysqli_query($conn,"delete from users where Name='".$uname."'");
	   echo "<center><h1>successfully deleted</h1></center>";
	  
    }
  
    else
    {
        echo "invalid details";

    }
}
?>
</body>
</html>