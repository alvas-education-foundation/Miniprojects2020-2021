<html>
<body>
<form method="post" action="change_pass_ver.php" align="center">
Username:<br>
<input type="text"  name="name" id="name" required="" placeholder="Username"><br/>
Current Password:<br>
<input type="password" name="currentPassword"><span id="currentPassword" class="required"></span>
<br>
New Password:<br>
<input type="password" name="newPassword"><span id="newPassword" class="required"></span>
<br>
Confirm Password:<br>
<input type="password" name="confirmPassword"><span id="confirmPassword" class="required"></span>
<br><br>
<input type="submit">
</form>
<br>
<br>
<center><h2><a href="signin.php">Sign IN</a><img src="user.gif" width='70' height='50'></img></center>
</body>
</html>
