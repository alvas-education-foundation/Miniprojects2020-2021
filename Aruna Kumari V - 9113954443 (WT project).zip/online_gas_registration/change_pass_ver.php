<?php
include_once 'connections.php';

$uname=$_POST['name'];
$currentPassword=$_POST['currentPassword'];
$newPassword=$_POST['newPassword'];
$confirmPassword = $_POST['confirmPassword'];

$result = mysqli_query($conn,"SELECT *from users WHERE Name='" . $uname . "'");
$row=mysqli_fetch_array($result);

if($_POST["currentPassword"] == $row["Password"] && $_POST["newPassword"] == $_POST["confirmPassword"] ) {
	
mysqli_query($conn,"UPDATE users set Password='" . $_POST["newPassword"] . "' WHERE Name='" . $uname . "'");
echo "<center><h2><img src='smile.jpg'>Password changed successfully</img></h2></center>";
echo "<a href='signin.php'>Back to login</a>";
}

 else{
 echo "Password is incorrect";
 echo "<a href='change_pass.php'>Try Again</a>";
}
?>