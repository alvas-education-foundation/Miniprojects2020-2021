<?php
//database constants
define("server","localhost");
define("user","Aruna");
define("pass","arunakumari06");
define("name","online_gas");

?>