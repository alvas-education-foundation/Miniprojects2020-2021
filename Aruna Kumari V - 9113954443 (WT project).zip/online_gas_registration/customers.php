<html>
<head>
<style>
body{
	 background-image: url('bck2.jpg');
	 background-size: cover;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
</head>
<body>
<ul>
    <li><a href="change_pass.php">Change Password</a></li>
  <li><a href="History.php">History</a></li>
  <li><a href="#contact">Edit Profile</a></li>
  <li><a href="account.php">Account</a></li>
  <li><a href="cancel.php">Booking Cancel</a></li>
  <li><a href="homepage.php">LogOut</a></li>
</ul>
<?php
 session_start();
include_once 'connections.php';

if(isset($_POST['name']))
{
    $uname=$_POST['name'];
    $pass=$_POST['pass'];
	$sql="SELECT * FROM `users` WHERE Name='".$uname."' AND Password='".$pass."' limit 1 ";
    
    $result=mysqli_query($conn,$sql);
   
    if(mysqli_num_rows($result)==1)
    {
      
	   $_SESSION['name'] = $uname;
	  
    }
  
    else
    {
        header('Location:signin.php');

    }
}
echo "<h1><center>Gas Booking</center></h1>";
echo "<h2><center><i>Welcome to your profile $uname</i></center></h2>";
$last_date = mysqli_query($conn,"select last_date from bookings Where Name='".$uname."'");
if($last_date->num_rows >0)
{
	while($row = $last_date->fetch_assoc())
	{
		$l = $row['last_date'];
	}
}
$cur_date = date("Y-m-d");
$c = strtotime($cur_date);
$lt = strtotime($l);
$diff = $c - $lt;
$result = round($diff / 86400);
if($result>=30)
		{
			echo "<form align='center' action='booking.php' method='post'>
	<input type='image' src='BookNow.png' alt='Submit' width='100' height='100'>
</form>";
}
else{
	echo "<h2>You can't book gas wait until u finish 30 days</h2>";
}
session_destroy();
?>
</body>
</html>
	