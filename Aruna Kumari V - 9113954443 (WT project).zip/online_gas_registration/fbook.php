<html>
<head>
<style>
body{
	 background-image: url('bck2.jpg');
	 background-size: cover;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
</head>
<body>
<ul>
  <li><a href="homepage.php">Home</a></li>
  <li><a href="change_pass.php">Change Password</a></li>
  <li><a href="#news">History</a></li>
  <li><a href="#contact">Edit Profile</a></li>
  <li><a href="account.php">Account</a></li>
  <li><a href="cancel.php">Booking Cancel</a></li>
</ul>
<center>
<?php

?>
<h1>Gas Booking</h1>
<?php
echo "<h2><i>Welcome to your profile $uname</i></h2>";
?>
<br><br><br>
<form action="fbookings.php?" method="post">
<table align="center">
	<th>Enter your Account Number</th>
   <tr><td>Account Number</td>
   <td><input type=text required="" name="account" size=20></td></tr>
<tr><td><input type="submit" name="submit" value="submit"></td>
<td><input type=reset name="reset" value="clear"></td></tr>
</table>
</form>
</center>
</body>
</html>
	