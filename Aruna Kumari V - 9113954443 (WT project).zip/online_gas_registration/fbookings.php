<?php
include_once 'connections.php';
$account=$_GET['account'];
$uname=$_GET['name'];
$result = mysqli_query($conn,"select Amount from users Where Acc_num='".$account."'");
if( $result->num_rows >=0)
{	 
	while($row = $result->fetch_assoc())
	{
		if($row['Amount']>=850)
		{
	mysqli_query($conn,"UPDATE users SET Amount=Amount-850 WHERE Acc_num ='" . $account . "'");
	echo "<center>";
	echo "<h2><img src='smile.jpg'>Booking is done successfully</img></h2>";
	echo "<a href='receipt.php?account=$account&name=$uname'>Print RECEIPT</a>";
	echo "</center>";
}
else{
	echo "<script>alert('Low Balance');</script>";
	echo "<script>window.location.href='homepage.php';</script>";
}
}}
?>
