<?php
session_start();
$uname = $_SESSION['name'];
include_once 'connections.php';
$result = mysqli_query($conn,"select *from bookings where Name='".$uname."'");
if($result->num_rows>0)
{
	while($row = $result->fetch_assoc())
	{
		echo "<center>";
		echo "<h2>Your Transaction Details</h2>";
		echo "<table>";
		echo "<th>Name</th><th>Booking Date</th><th>Delivery Date</th><th>Amount</th>";
		echo "<tr>";
		echo "<td>";
		echo $row['Name'];
		echo "</td>";
		echo "<td>";
		echo $row['last_date'];
		echo "</td>";
		echo "<td>";
		echo $row['Delivery_date'];
		echo "</td>";
		echo "<td>Rs.850</td>";
		echo "</tr>";
		echo "</table>";
		echo "<center>";
	}
}
else
{
	echo "<script>alert('No Transactions Yet!!');</script>";
	echo "<script>window.location.href='signin.php';</script>";
}

?>
