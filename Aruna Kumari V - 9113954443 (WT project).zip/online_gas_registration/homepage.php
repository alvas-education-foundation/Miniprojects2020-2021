<html>
<head>
<title>Online Gas Booking</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style>
body{
	 background-image: url('bck1.jpg');
	 background-size: cover;
}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}
li {
  float: left;
}
li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
li a:hover {
  background-color: #111;
}
</style>
</head>
<body>
<h1>Online Gas Registration</h1>
<img src="cylinder.jpg" width='200' height='200' align='right'></img>
<ul>
	<li><a href="admin.php">Admin</a></li>
  <li><a href="#contact">Contact</a></li>
   <li><a href="#about">FAQ</a></li>
  <li><a href="#about">About</a></li>
  <li><a href="cancel.php">Delete My Account</a></li>
</ul>
<form action="registered.php" method="post">

   <table align=center>
   <th><h2>SIGN UP<img src="user.gif" width='70' height='50'></img></h2>

<tr> <td>Name</td><td>  <input type="text" required=" " name="uname" size=20></td></tr>

<tr><td>Password  </td><td><input type="password" required=" " name="pwd" size=20></td></tr>

<tr><td>E-Mail  </td><td><input type="email" required="" name="email" size=20></td></tr>

<tr><td>Account Number  </td><td><input type=text required="" name="account" size=20></td></tr>

<tr><td>Phone Number  </td><td><input type=int required="" name="phone" size=10></td></tr>

<tr><td>Add Amount to Your Wallet  </td><td><input type=text required="" name="amt" size=20></td></tr>

<tr><td>Address  </td><td><textarea name="address" size=40 required="" placeholder="Residential Address"></textarea></td></tr>

<tr><td><input type="submit" name="submit" value="submit"></td>
<td> <input type=reset name="reset" value="clear"></td></tr>
</table>
</form>
<br<<br>
<h3><center><a href="signin.php">Already User</a></center></h3>
</body>
</html>