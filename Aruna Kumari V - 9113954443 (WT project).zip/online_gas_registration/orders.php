<?php
include_once 'connections.php';
if(isset($_POST['name']))
{
    $uname=$_POST['name'];
    $pass=$_POST['pass'];
	$sql="SELECT * FROM `admin` WHERE Name='".$uname."' AND Password='".$pass."' limit 1 ";
    
    $result=mysqli_query($conn,$sql);
   
    if(mysqli_num_rows($result)==1)
    {
      
	   $_SESSION['name'] = $uname;
	  
    }
  
    else
    {
        header('Location:admin.php');

    }
}
$result = mysqli_query($conn,"select * from bookings");
$cur_date = date("Y-m-d");
if($result->num_rows>0)
{
	while($row = $result->fetch_assoc())
	{
		echo "<center>";
		echo "<h1>ORDERS</h1>";
		echo "<table>";
		echo "<th>Name</th><th>Booking Date</th>";
		echo "<tr>";
		echo "<td>";
		echo $row['Name'];
		echo "</td>";
		echo "<td>";
		echo $row['last_date'];
		echo "</td>";
		echo "<td><input type='checkbox'></td>";
		echo "</tr>";
		echo "</table>";
		echo "</center>";
}}
else{
	echo "<h1>NO ORDERS</h1>";
}
?>