<html>
<?php
include_once 'connections.php';
$account=$_GET['account'];
$uname=$_GET['name'];
$cur_date = date("Y-m-d");
$last_date = date("Y-m-d");
mysqli_query($conn,"INSERT into bookings(Name,Acc_num,Cur_date,last_date) values('$uname','$account','$cur_date','$last_date')");
$result = mysqli_query($conn,"select *from users where Acc_num='".$account."'");
if($result->num_rows >0)
{
	while($row = $result->fetch_assoc())
	{
	echo "<table align=center>";
	echo "<th><h2>BOOKING DETAILS</h2></th>";
	echo "<tr><td><h3>Name:</td><td>$row[Name]</h3></td></tr>";
	echo "<tr><td><h3>E-Mail:</td><td>$row[Email]<h3></td></tr>";
	echo "<tr><td><h3>Account Number: </td><td>$row[Acc_num]<h3></td></tr>";
	echo "<tr><td><h3>Phone Number:</td><td>$row[Phone_num]<h3></td></tr>";
	echo "<tr><td><h3>Price</h3></td><td><h3>Rs.820</h3></td></tr>";
	echo "<tr><td><h3>Delivery charges</h3></td><td><h3>Rs.30</h3></td></tr>";
	echo "<tr><td><h3>Address</td><td>$row[Address]</h3></td></tr>";
	}
}
echo "<center><h3>DATE: $cur_date</h3></center>";
?>
<tr id="print">
    <td colspan="2" align="center">
        <input type="button" onclick="printer()" value="Print">
    </td>
</tr>
</table>
<script type="text/javascript">
function printer()
    {
        document.getElementById("print").style.display = 'none';
        window.print();
    }
function logout()
    {
        document.getElementById("logout").style.display = 'none';
        location.replace("homepage.php");
    }
</script>
<center><input type="button" onclick="logout()" value="logout" id="logout"></center>
</html>
