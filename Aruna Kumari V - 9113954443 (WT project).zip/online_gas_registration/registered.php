<?php
$uname = $_POST['uname'];
$pwd = $_POST['pwd'];
$email = $_POST['email'];
$account = $_POST['account'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$amt = $_POST['amt'];

include_once 'connections.php';
$sql="SELECT * FROM `users` WHERE Acc_num='".$account."' AND Email='".$email."' limit 1 ";
$result=mysqli_query($conn,$sql);  
if($result->num_rows==FALSE)
{
	mysqli_query($conn,"INSERT into users(Name,Password,Email,Acc_num,Phone_num,Address,Amount) values('$uname','$pwd','$email','$account','$phone','$address',$amt)");
	echo "<center><h2><img src='smile.jpg'>Successfully Registered</img></h2></center>";
	echo "<center><a href='fbookings.php?name=$uname&account=$account'><b>BOOK NOW</b></a></center><br><br>";
	echo "<center><a href='homepage.php'><b>HOME</b></a></center>";
}
else
{
	echo "<script>alert('User already exists');</script>";
	echo "<script>window.location.href='homepage.php';</script>";
}
?>





