<!DOCTYPE html>
<head>
<title></title>
</head>
<body>
<link rel = "stylesheet" type = "text/css" href = "menu.css">
<link rel = "stylesheet" type = "text/css" href = "Headerbtn.css">
</head>
<body>

        <div align="center" style="top:0px">
          <table width="1330" bgcolor="#FFFFFF">
          <tr>
	     <td><img src="logo.png">		 <table align="right">
		 <tr>
<td><a href="index.php?logout">Logout</a></td>
		 </tr>
		 </table>
</div>  
		</td>
	 
            </tr>
            <tr>
              <td>
			  			
			  <table align="center" style = "background-color:white;"width="1310">
                <tr> 	
					<td style = "text-align:center"><a href="AddProduct.php" target="frame"><button class = "btn2">Add Product</button></a></td>

                  <td style = "text-align:center"><a href="UpdateProduct.php" target="frame"><button class = "btn2">Update Product</button> </a></td>                  
				  <td style = "text-align:center"><a href="DeleteItems.php" target = "frame"><button class = "btn2">Delete Product</button></a> </td>
                  <td style = "text-align:center"> <a href="AllOrders.php" target="frame"><button class = "btn2">Orders</button></a></td>
				  <td style = "text-align:center"><a href="Users.php" target="frame"><button class = "btn2">Users</button></a></td>
				  <td style = "text-align:center"><a href="Feedback.php" target="frame"><button class = "btn2">Feedback</button></a></td>
                </tr>
		      </table></td>
                  </tr>
			          </table>
</div>

</body>
</html>
