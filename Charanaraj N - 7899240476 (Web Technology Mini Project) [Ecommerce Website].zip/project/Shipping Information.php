<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Shipping Information</title>
</head>

<body>
<div style = "height: 1000px; width: 1000px;" >
<br>
<div align = center	 style= "font-family:Geneva, Arial, Helvetica, sans-serif; font-size:20px; padding: 5px; height: 30px; width: 800px; background-color: #009FFF;"> Shipping Information </div>

<form  method="post" name="bill">
  <table align="center" width="400" style= "font-family:Geneva, Arial, Helvetica, sans-serif;" cellpadding="15" cellspacing="5" >
<tr>
    <td><input type="text" placeholder="First Name" class="in3" size="20" /></td>
</tr>

<tr>
	<td><input type="text" placeholder="Last Name " size="20" /></td>
</tr>
  
<tr>
	<td><input type="text" placeholder="E-mail"  size="20"/></td>
</tr>

<tr>
	<td><input type="text" placeholder="Country" size="20"/></td>
</tr>

<tr>
	<td><input type="text" placeholder="State" size="20" /></td>
</tr>

<tr>
	<td><input type="text" placeholder="City" size="20"/></td>
</tr>
 
<tr>
	<td><input type="text" placeholder="Address" size="20" /></td>
</tr> 

<tr>
	<td><input type="text" placeholder="Contect Phone" size="20" /></td>
</tr>

<tr>
	<td><input type="text" placeholder="Comment" size="20" /></td>
</tr>
</table>
</form>
<div align = center style= "font-family:Geneva, Arial, Helvetica, sans-serif; font-size:20px; padding: 5px; height: 25px; width: 800px; background-color: #04BBB7;"></div>
</div>

</body>
</html>
