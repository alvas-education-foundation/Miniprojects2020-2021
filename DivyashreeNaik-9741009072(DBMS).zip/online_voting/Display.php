<?php
require('connection.php');

session_start();
//If your session isn't valid, it returns you to the login screen for protection
if(empty($_SESSION['member_id'])){
 header("location:access-denied.php");
}
//retrive positions from the tbcandidates table
$result=mysqli_query($con,"CALL `disp_candidate` ();")
or die("There are no records to display ... \n" . mysqli_error()); 
if (mysqli_num_rows($result)<1){
    $result = null;
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ONLINE VOTING SYSTEM:Voting Page</title>
<link href="css/user_styles.css" rel="stylesheet" type="text/css" />   
<script language="JavaScript" src="js/user.js">
</script>
</head>
<body bgcolor="tan">
<center><b><font color = "white" size="6">ONLINE VOTING SYSTEM</font></b></center><br><br>
<div id="page">
<div id="header">
  <h1>CANDIDATE LIST</h1>
  <a href="student.php">Home</a> | <a href="vote.php">Current Polls</a> | <a href="Display.php">Candidate List</a> |<a href="manage-profile.php">Manage My Profile</a>| <a href="logout.php">Logout</a>
</div>
<div id="container">
<hr>
<table border="0" width="420" align="center">
<CAPTION><h3>CANDIDATE LIST</h3></CAPTION>
<tr>
<th> ID</th>
<th> NMAE</th>
<th> POSITION </th>
</tr>

<?php
//loop through all table rows
while ($row=mysqli_fetch_array($result)){
echo "<tr>";
echo "<td>" . $row['candidate_id']."</td>";
echo "<td>" . $row['candidate_name']."</td>";
echo "<td>". $row['candidate_position']."</td>";
echo "</tr>";
}
mysqli_free_result($result);
mysqli_close($con);
?>
</table>
<hr>
</div>
<div id="footer"> 
</div>
</div>
</body>
</html>
