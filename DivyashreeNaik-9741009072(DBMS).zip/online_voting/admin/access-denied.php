<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Simple PHP Polling System Access Denied</title>
<link href="css/admin_styles.css" rel="stylesheet" type="text/css" />
</head>
<body bgcolor="tan">
<center><a href ="https://sourceforge.net/projects/pollingsystem/"><img src = "images/logo" alt="site logo"></a></center><br>     
<center><b><font color = "white" size="6">ONLINE VOTING SYSTEM</font></b></center><br><br>
<body>
<div id="page">
<div id="header">
  <h1>Access Denied</h1>
  <a href="admin.php">Home</a> | <a href="manage-admins.php">Manage Administrators</a> | <a href="positions.php">Manage Positions</a> | <a href="candidates.php">Manage Candidates</a> | <a href="results.php">Poll Results</a>
</div>
<div id="container">
<div class="err">Access Denied!</div>
  <p>You don't have access to this resource. <a href="login.html">Click here</a> to login first.</p>
</div>
<div id="footer"> 
</div>
</div>
</body>
</html>
