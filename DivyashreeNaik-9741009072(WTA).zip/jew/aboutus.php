<body style="background-image: url(images/au.jpg);background-size: cover;">
<br>
<h1><font color="gold">About Us</font></h1>
<hr><br>
<p align="justify"><font color="white" size="5">An online Jewelry shop that allows users to check for various Jewelry available at the online store and purchase online.The project consists of list of Jewelry products displayed in various models and designs.The user may browse through these products as per categories.If the user likes a product he may add it to his shopping cart.
<p>Once user wishes to checkout he must register on the site first. He can then login using same id password next time. Now he may pay through a credit card or cash on delivery.Once the user makes a successful transaction he gets a copy of the shopping receipt on his email id.Here we use inbuilt system framework to make the entire frontend. The middle tier or code behind model is designed for a strong processing support.</font></p>



















































