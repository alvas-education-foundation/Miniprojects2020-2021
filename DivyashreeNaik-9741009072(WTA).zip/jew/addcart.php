<?php
require('dbfun.php');
session_start();
$pids=array();
$tprice="";

?>
<html>
<body style="background-image: url(images/d.jpg);background-size: cover;">
  <!--<h1><center>Welcome to the  User Page!!!!</center></h1>-->
<form name=show method=get action="addcart.php">
<font color="white">Category:</font>
<select name=category onchange="this.form.submit()">
<option> Choose</option>
<?php
$categorys=getProductcraftCategory();
$category="";
if(isset($_REQUEST['category']))
    $category=$_REQUEST['category'];
foreach ($categorys as $value)
{
    if($category==$value)
          echo "<option selected>".$value."</option>";
        else
           echo "<option >".$value."</option>";
}
?>
</select><br><br>
<table border=1 bgcolor=lightpink width="900">

<?php
$msg="";
$category="";
$prod_dets=array();
if(isset($_REQUEST['category']))
    if($_REQUEST['category']!='Choose')
       {
        echo "<tr bgcolor=gold><td>Images</td><td>Jewellery Id</td><td>Jewellery Name</td><td>Price</td><td>Jewellery Details</td><td>Select</td><td>NOI</td><td>order</td></tr>";
        $category=$_REQUEST['category'];
        $prod_dets=CraftsCategory($category);
        foreach ($prod_dets  as $prod_det) 
        {
          $filesrc="images/$prod_det[0]".".jpg";
          
          $str="<tr><td><img height=130 width=150 src=$filesrc></td>";
          $str=$str."<td>$prod_det[0]</td>";
          $str=$str."<td>$prod_det[1]</td>";
          $str=$str."<td>$prod_det[2]</td>";
          $str=$str."<td>$prod_det[3]</td>";
        $str=$str."<td><input type=checkbox name='ch$prod_det[0]'></td>";
        $str=$str."<td><select name=noi$prod_det[0]><option>1</option>
        <option>2</option><option>3</option><option>4</option>
        </select></td>";
       $str=$str."<td><a href='buy.php'>buy</a></td></tr>";
        echo $str;
        $pids[$prod_det[0]]=$prod_det[3];
       
        }
         $_SESSION['pids']=$pids;
       }
     else
       $msg="Please select the category";
      echo $msg;
?>
</table><br>
<!--<input type="submit" value="show amt" name=tprice>
<input type="submit" value="ADD to CART" name=add>
<a href="buy.php"><input type="button" value="Order" name=buy></a>-->
<a href="login.php"><input type="button" value="Back" name=back></a>
</br>
<table border=1>
<!--<?php

if(isset($_REQUEST['tprice']))
{

$pids=$_SESSION['pids'];
$tprice=0;
$total=0;
echo "<tr><td>Craft ID</td><td>qty</td><td>price</td></tr>";
foreach($pids as $id => $price)
{
 
  $chname="ch".$id;
  if(isset($_REQUEST[$chname]))
  {
    $pqty="noi".$id;
    $noqty=$_REQUEST[$pqty];

    $total=$noqty*$price;
    $tprice=$noqty*$price+$tprice;
    //addcart($id,$Price,$noqty,$total);

    echo "<tr><td>$id</td><td>$noqty</td><td>$price</td></tr>";
                     /* $url=$_SERVER['REQUEST_URI'];
$url="http://localhost".$url."";
echo $url;*/
     //addcart($id,$noqty);
  }
   


}
}

?>

<?php

if(isset($_REQUEST['add']))
{

$pids=$_SESSION['pids'];
$tprice=0;
$total=0;

foreach($pids as $id => $price)
{
  echo $id;
  $chname="ch".$id;
  if(isset($_REQUEST[$chname]))
  {
    $pqty="noi".$id;
    $noqty=$_REQUEST[$pqty];

    $total=$noqty*$price;
    $tprice=$noqty*$price+$tprice;
    echo "<tr><td>$id</td><td>$noqty</td><td>$price</td></tr>";
    
    addcart($id,$price,$noqty,$total);
  }
   


}
}
?>-->


</table>
<span><?php 
echo $tprice; ?></span>


</form>
</body>
</html>

