<?php
	require('dbfun.php');
	session_start();
	$msg='';
	$msg2='';
	if(isset($_REQUEST['add']))
	{
		$pname=$_REQUEST['pname'];
		$pid=$_REQUEST['pid'];
		$category=$_REQUEST['category'];
		$price=$_REQUEST['price'];
		$prod_det=$_REQUEST['prod_det'];

		
		if(add_craft($pname,$pid,$category,$price,$prod_det))
			$msg="<font color=gold><b>Jewellery Added Successfully</b></font>";
		else
			$msg="<font color=white><b>Jewellery Added unsuccessfully</b></font>";


		
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Craft Page</title>
	<style type="text/css">
		#main{
		
		}
	</style>
</head>
<body style="background-image: url(images/d.jpg);background-size: cover;">
	<center>
		<form id="main" name="form2" action="" method="get">
		<h1><font color="gold">Add jewellery</font></h1>
		<table>
			<tr>
				<td><font color=gold><b>Jewellery Name :&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>
				<td><input type="text" name="pname" value="" placeholder="enter jewellery name" required/></td>
			</tr>
			<tr></tr><tr></tr><tr></tr>
			<tr>
				<td><font color=gold><b>Jewellery Id :&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>
				<td><input type="text" name="pid" value="" placeholder="enter jewellery id" required/></td>
			</tr><tr></tr><tr></tr><tr></tr>
			
			<tr>
				<td><font color=gold><b>Catagory:&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>
				<td><select style="width:173px;" name="category" required>
					<option value="">choose</option>
					<option value="gold rings">gold rings</option>
					<option value="d necklace">d necklace</option>
					<option value="d ring">d ring</option>
				</select></td>
			</tr><tr></tr><tr></tr><tr></tr>
			
			<tr>
				<td><font color=gold><b>Price:&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>
				<td><input type="text" name="price" value="" placeholder="enter the price" required/></td>
			</tr><tr></tr><tr></tr><tr></tr>
			<tr>
				<td><font color=gold><b>Jewellery details:&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>
				<td><input type="text" name="prod_det" value="" placeholder="enter details"required/></td>
			</tr><tr></tr><tr></tr><tr></tr>
			
		<tr><td></td>
		<td><a href="admin.php"><input type="button" name="back" value="Back"></a>&nbsp;&nbsp;&nbsp;&nbsp;
		<input type="submit" name="add" value="Add Craft"></td>
		</tr>
		<tr><td></td>
			<td><span><?php echo $msg; ?>
				<?php echo $msg2; ?>
			</span></td>
		</tr>
		</table>
		</form>
	</center>
</body>
</html>