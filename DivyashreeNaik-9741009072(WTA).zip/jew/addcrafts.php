<?php
require('connection.php');
session_start();
$msg="";
$mid=getNewPackagesid();
if(isset($_REQUEST['submit']))
{
	
	//$id=$_REQUEST['id'];
	$pname=$_REQUEST['pname'];
	$loc=$_REQUEST['loc'];
	$price=$_REQUEST['price'];
	$type=$_REQUEST['type'];
	$fea=$_REQUEST['fea'];
	$det=$_REQUEST['det'];
	$stat=$_REQUEST['stat'];
	$remark=$_REQUEST['remark'];
		
	if(addPackage($pname,$loc,$price,$type,$fea,$det,$stat,$remark))
	{
		$msg="<font color=green>Added successfully</font>";
	}
		else
			$msg="<font color=red>Error</font>";

	$filename=$_FILES['fileToUpload']['name'];
	$file_tmp=$_FILES['fileToUpload']['tmp_name'];
	 $file_size = $_FILES["fileToUpload"]["size"];

	$path_parts=pathinfo($_FILES['fileToUpload']['name']);
	//die($path_parts)
	$extension=$path_parts['extension'];
	if(!($extension=="jpg" || $extension=="png" || $extension=="bmp"))
	{
		die("file format is not correct");
	}
	if($filename!="" )
	{
		if($file_size<=500000)
		{
			
			//$target_dir="~/images/";//~ ->current directory
			$newfilename=$mid.".jpg";
			move_uploaded_file($file_tmp, "images".$newfilename);
			die('uploaded succ');
		}
		else
		{
			echo "File size exceeded";
		}

	}

	if(!$_FILES['fileToUpload'])
	
	{	
		echo "Do you want to add product without an image: <input type=submit name=yes value=yes>
			<input type=submit name=no value=no>";

	}

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Packages</title>
<link rel="stylesheet" type="text/css" >
</head>

<style type="text/css">
	td
	{
		height: 50px;
		width: 200px;

	}
	input,#span1
	{
		width: 200px; height: 30px; border-radius: 5px;
	}
	a{
		text-decoration: none;
		float: right;
		color: black;
	}
	ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: right;
  border-right:1px solid #bbb;
}

li:last-child {
  border-right: none;
}

li a {
  display: block;
  color: white;
  float: right;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;

}

li a:hover {
  background-color: #111;
  float: right;
}

</style>
<body>
	<div id="main_header"><h2>ONLINE MOVIE TICKET BOOKING SYSTEM</h2></div>
	<marquee height=50px width=100% bgcolor=black direction="left"><font size=5 color="red">
	</font></marquee>
	<ul><li><a href="admin1.php" ><font size=5><b>Back</b></font></a></li></ul>
<hr color=black>
	<div id="header"><h2>Add Packages</h2></div>
	<div id="body">
		<form name=add_packages action="" method="post" enctype="multipart/form-data">
			<table>
				<tr>
					<td><b>Package ID</b></td>
					<td><span id=span1 name="id"><?php echo $mid."<br>";?></span></td>
					<td><b>Package name</b></td>
					<td><input type="text" name="pname"  required="Required"></td>
				</tr>
				<tr>
					<td><b>Package Location</b></td>
					<td><input type="text" name="loc"  required="Required" ></td>
					<td><b>price</b></td>
					<td><textarea name="price" style="border-radius: 5px; height:50px ;width:200px; " required="Required"></textarea></td>
				</tr>
				<tr>
					<td><b>Package Type</b></td>
					<td><textarea name="type" style="border-radius: 5px; height:50px ;width:200px; " required="Required"></textarea></td>
					<td><b>Package Feature</b></td>
					<td><textarea name="fea" style="border-radius: 5px; height:35px ;width:200px; " required="Required"></textarea></td>
					
				</tr>
				<tr>
					<td><b>Package Details</b></td>
					<td><textarea name="det" style="border-radius: 5px; height:35px ;width:200px; " required="Required"></textarea></td>
						
					<tr>
					<td><b>Package city</b></td>
					<td><textarea name="city" style="border-radius: 5px; height:35px ;width:200px; " required="Required"></textarea></td>
						
					<td><b>Status</b></td>
					<td><select name="stat" style="border-radius: 5px; height:35px ;width:200px; ">
						<option>Select</option>
						<option>ok</option>
						<option>block</option>
						</td>
				</tr>
				<tr>
					<td><b>Remarks</b></td>
					<td><input type="text" name="remark" ></td>
					<td><b>Upload image</b></td>
					<td><input type="file" name="fileToUpload" id="fileToUpload"></td>
				</tr>
				<tr>
					
					<td><input type="submit" name="submit" value="Submit" style="width: 100px; height: 30px; border-radius: 5px;"></td></tr>
			</table>
		</form>
	
	</div>
	<?php
	echo "$msg";
	?>
	<hr color=black>
<div id="footer"></div>
</body>
</html>