<!DOCTYPE html>
<html>
<head>
	<title>admin</title>
	<style>
		#div1 a{
			text-decoration: none;
			color: pink;
			font-size: 20px;
			padding: 10px 10px; 
			font-weight: bold;
		}
		#div1{
			
			height: 30px;
			padding: 10px 10px;
		}
		a{
			text-decoration: none;
			color: white;
			font-size: 18px;
			padding: 10px 10px; 
			
		}
	</style>
</head>
<body style="background-image: url(images/b.jpg);background-size: cover;">
	<h1><font color="gold">Welcome to Admin Page</font></h1>
	<div id="div1"> 
	<table border="0">
		<tr>
			<td>| <a href="addcraft.php">Add Jewellery</a></td>
			<td>| <a href="dispcraft.php">Display Jewellery</a></td>
			<td>| <a href="updatecraft.php">Update Jewellery</a></td>
	        <td>| <a href="logout.php">Logout</a></td>

</body>
</html>