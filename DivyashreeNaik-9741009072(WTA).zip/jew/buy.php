<body style="background-image: url(images/d.jpg);background-size: cover;">
<BR><marquee direction="down" height="500"><font size="6" color="white">Ordered successfully!!!</font></marquee>
<a href="addcart.php"><input type="button" value="Back" name=back></a>