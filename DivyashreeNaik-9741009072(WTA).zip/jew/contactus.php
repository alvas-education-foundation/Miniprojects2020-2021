<body style="background-image: url(images/cu.jpg);background-size: cover;">

<h1><font color="gold">Contact Us</font></h1>
<hr>
<h2><font color=white>We care for customers,and to solve all their problems.</font></h2>
<div class="col-lg-12">
        <div id="form-outer">
            <div id="frm-contact">
                <div>
                    <font color="white">Name :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font><input type="text" name="userId" id="userId"
                        class="demoInputBox" PlaceHolder="Name">
                </div><br>
                <div>
                    <font color="white">Email-id :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font><input type="text" name="userEmail" id="userEmail"
                        class="demoInputBox" PlaceHolder="Email">
                </div><br>
                <div>
                    <font color="white">Comment :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea name="content" id="content"
                        class="demoInputBox" rows="3"
                        PlaceHolder="Comment"></textarea>
                </div><br>
                <div id="mail-status">
                    <a href="customer.php"><button name="submit" class="btnAction">Send</button></a>
                </div>
        </div>  
</div>
</div>
	<script src="js/jquery-3.2.1.min.js"></script> 
	 <script type="text/javascript">
            $(document).ready(function(){

                	$( "#btn-contact" ).on( "click", function() {
                        
                    if ($("#frm-contact").is(":hidden"))
                    {
                        $("#frm-contact").slideDown("slow");
                    }
                    else
                    {
                        $("#frm-contact").slideUp("slow");
                    }
                });
                
            });
      
</script>
<br>
<p><b>CONTACT ADDRESS :</b></p>
<p>EMAIL:manvita@gmail.com </p>
<p>PLACE:Mangalore </p>
<p>Mob no:9978564123</p>
</div>
