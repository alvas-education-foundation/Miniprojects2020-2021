<body style="background-image: url(images/a.jpg);background-size: cover;">

<br><marquee direction="down" height="500"><font size="6" color="white">This message is sent successfully!!!</font></marquee>