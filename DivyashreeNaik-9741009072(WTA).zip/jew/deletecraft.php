<?php
	
	require('dbfun.php');
//$pid="";	

$msg="";
if(isset($_GET['del']))
		

{
	
	$pid=$_GET['del'];
	echo "$pid";

	if(delete($pid)==true)
		{
		$msg="<font color=red>deleted successfully</font>";	
		echo  $msg;
		}
	else
	{
		$msg="<font color=red>invalid</font>";
		echo $msg;
	}
}
?>








