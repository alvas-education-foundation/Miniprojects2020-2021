<?php

 require('dbfun.php');
 session_start();
 $pids=array();
 
 
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}


.container {
  padding: 230px;
  background-color: white;
}

.img{
  background-image: url(img/pdf.png);
  -webkit-background-size:cover;
            background-size:cover;
            background-position: center;
 padding: 200px;
}

input[type=text], input[type=password] {
  width: 35%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}


a {
  color: red;
}

.middle{
   width: 25%;
  line-height: 10px;
  float: right;
}

#buttonone{
  background-color: white;
  border: none;
  font-size: 12px;
  text-transform: uppercase;
  font-weight: bold;
  color: white;
  line-height: 40px;
  width: 120px;
  font-family: 'Montserrat', sans-serif;
  margin-top: 5px;
  background-color: white;
  cursor: pointer;
  border-radius: 20px;
}


</style>
</head>
	<body>

  <div class="middle">
          <button id="buttonone"><a class="btn  ml-2 " href="login.php">Back</a></button>
         </div>
	 <form method=get action="">
    <div class="img">
    <h1>View Crafts Details</h1><br><br>
	 	Crafts category:
	 	<select name=category onchange="this.form.submit()">
	 		<option>choose</option>
	 		<?php
             $categorys=getcategorys();
             $category="";
             if(isset($_REQUEST['category']))
             	$category=$_REQUEST['category'];
             foreach ($categorys as $value) 
             {
             	if($category==$value)
             		echo "<option selected>".$value."</option>";
             	else
             		echo "<option>".$value."</option>";
             }
	 		?>
	 	</select><br><br>
	 		
	 	     <table border=1 bgcolor=lightpink width="900">	 	     	
   <?php
   $msg="";
   $pid="";
   $prod_dets=array();
   
  // $str="";
  if(isset($_REQUEST['category']))
             	if($_REQUEST['category']!='choose')
             	{
                echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
             		echo "<tr bgcolor=gold><td>images</td><td>pname</td><td>pid</td><td>price</td><td>prod_det</td><td>Delete</td></tr>";
             		$pid=$_REQUEST['category'];
             		$prod_dets=getCraftbycategory($category);
             		$pids=array();$i=0;
                //$url=$_SERVER['REQUEST_URI'];
                //$url="http://localhost".$url;
             		foreach ($prod_dets as $prod_det) 
             		{
          $filesrc="images/$prod_det[0]".".jpg";
          $str="<tr><td><img height=130 width=150 src=$filesrc></td>";

             		  $str="<tr><td>$prod_det[0]</td>";
             		  $str=$str."<td>$prod_det[1]</td>";
             		   $str=$str."<td>$prod_det[2]</td>";
             		    $str=$str."<td>$prod_det[3]</td>";
                     $str=$str."<td>$prod_det[4]</td>";
                    $str=$str."<td>$prod_det[5]</td>";
                   
             		    //$str=$str."<td><a href='update_subject.php?pname=$sdet[1]'>edit</a></td>";
                     $str=$str."<td><a href='delete.php?del=$sdet[0]'onclick= 'return checkdelete()'>delete</a></td>";
             		   
                        


                         echo $str;
                         $pids[$prod_det[0]]=$prod_det[3];
                         $_SESSION['pids']=$pids;

             		    
             		}
             	}
             	else
             		$msg="please select the pid";
             	    echo $msg;
	 ?>
	 </table><br><br>

   
   
  </br>
	  </div>
	 </form>

   <script>
    function checkdelete()
    {
      return confirm('are you sure you want to delete data????');
    }
 </script>

	</body>
</html>