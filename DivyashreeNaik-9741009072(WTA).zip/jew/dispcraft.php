<?php
require('dbfun.php');
session_start();
$pids=array();
$price="";

?>
<html>
<body style="background-image: url(images/d.jpg);background-size: cover;">
<form name=show method=get action="">
  
<font color=gold>Category:&nbsp;&nbsp;&nbsp;&nbsp;</b></font>
<select name=category onchange="this.form.submit()">
<option> Choose</option>
<?php
$categorys=getProductCategory();
$category="";
if(isset($_REQUEST['category']))
    $category=$_REQUEST['category'];
foreach ($categorys as $value)
{
	if($category==$value)
          echo "<option selected>".$value."</option>";
     	else
     	   echo "<option >".$value."</option>";
}
?>
</select><br>
<br><table  border="1" bgcolor=lightpink width="900">

<?php
$msg="";
$category="";
$prod_dets=array();
if(isset($_REQUEST['category']))
    if($_REQUEST['category']!='Choose')
       {
        echo "<tr bgcolor=gold><td>images</td><td>jewellery Id</td><td>Jewellery Name</td><td>Price</td><td>Jewellery details<td>Delete</td></tr>";
        $category=$_REQUEST['category'];
        $prod_dets=getProductsByCategory($category);
        foreach ($prod_dets  as $prod_det) 
        {
          $filesrc="images/$prod_det[0]".".jpg";
          
          $str="<tr><td><img height=130 width=150 src=$filesrc></td>";
         // $str=$str."<td>$filesrc</td>";
          $str=$str."<td><font>$prod_det[0]</font></td>";
          $str=$str."<td><font>$prod_det[1]</font></td>";
          $str=$str."<td><font>$prod_det[2]</font></td>";
          $str=$str."<td><font>$prod_det[3]</font></td>";
          $str=$str."<td><a href='deletecraft.php?del=$prod_det[0]''>delete</a></td></tr>";
       // $str=$str."<td><input type=checkbox name='ch$pdet[0]'></td>";
      // $str=$str."<td><select name=noi$pdet[0]><option>1</option>
        //<option>2</option><option>3</option><option>4</option>
        //</select></td></tr>";
        echo $str;
        $pids[$prod_det[0]]=$prod_det[3];
       
        }
         $_SESSION['pids']=$pids;
       }
     else
       $msg="<br><font color=gold>Please select the category</font>";
      echo $msg;
?>
</table><br>
<!--<input type="submit" value="show amount" name=price>

</br>-->
<!--<table border=1>
<?php

if(isset($_REQUEST['tprice']))
{

$pids=$_SESSION['pids'];
$tprice=0;
$total=0;
echo "<tr><td>ID</td><td>qty</td><td>price</td>  </tr>";
foreach($pids as $id => $Price)
{
 
  $chname="ch".$id;
  if(isset($_REQUEST[$chname]))
  {
    $pqty="noi".$id;
    $noqty=$_REQUEST[$pqty];

    $total=$noqty*$Price;
    $tprice=$noqty*$Price+$tprice;
    //addcart($id,$Price,$noqty,$total);

    echo "<tr><td>$id</td><td>$noqty</td><td>$Price</td></tr>";
     //addcart($id,$noqty);
  }
   


}
}
?>
</table>-->
<span><?php 
//echo $tprice; ?></span>
</form>
<a href="admin.php">back</a>
</body>
</html>
