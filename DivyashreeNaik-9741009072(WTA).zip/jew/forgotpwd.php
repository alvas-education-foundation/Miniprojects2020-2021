<?php
	require('dbfun.php');
	$msg='';
	$msg2='';
	if(isset($_REQUEST['submit']))
	{
		$id=$_REQUEST['uid'];
		$answer=$_REQUEST['answer'];
		$pwd=forgotpwd($id,$answer);
		$msg="".$pwd;
	}


	if(isset($_REQUEST['submit_id']))
	{
		$id=$_REQUEST['uid'];
		$answer=$_REQUEST['answer'];
		$question=question($id);
		$msg2="".$question;
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Find Password</title>
</head>
<body style="background-image: url(images/a.jpg);background-size: cover;">
	<center>
		<form name="form" action="" method="get">
			<h1 ><font color=gold>Forgot Password?</font></h1>
			<table>
			<tr>
				<td><font color=gold><b>User ID :</b></font></td>			
				<td><br><input type="text" name="uid" value="<?php if(isset($_REQUEST['uid'])) echo $_REQUEST['uid'] ?>">
				<input type="submit" name="submit_id" value="Submit ID"><br><br>
				<span >
					<?php 
						echo "".$msg2;
					?>
				</span></td><br><br>
			<tr>
				<td><font color=gold><b>Answer:</b></font></td>
				<td><br><input type="text" name="answer" value="<?php if(isset($_REQUEST['answer'])) echo $_REQUEST['answer'] ?>">	
				<input type="submit" name="submit" value="Submit"><br><br>
				<?php echo $msg ?></td></tr><br><br>
				<tr><td><a href="login.php"><input type="button" name="back" value="Back"></a></td></tr>
			</table>
		</form>
	</center>
</body>
</html>