-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2019 at 05:06 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jewells`
--

-- --------------------------------------------------------

--
-- Table structure for table `productinfo`
--

CREATE TABLE IF NOT EXISTS `productinfo` (
  `pname` varchar(30) NOT NULL,
  `pid` varchar(10) NOT NULL,
  `category` varchar(10) NOT NULL,
  `price` float NOT NULL,
  `prod_det` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productinfo`
--

INSERT INTO `productinfo` (`pname`, `pid`, `category`, `price`, `prod_det`) VALUES
('ring 1', '001', 'gold rings', 15000, '24 carat gold plated'),
('ring 2', '002', 'gold rings', 15000, '24 carat gold plated'),
('necklace 1', '003', 'd necklace', 20000, '22 carat diamond '),
('necklace 2', '004', 'd necklace', 20000, '22 carat diamond'),
('necklace 3', '005', 'd necklace', 20000, '22 carat diamond '),
('necklace 4', '006', 'd necklace', 25000, '22 carat diamond '),
('necklace 5', '007', 'd necklace', 25000, '22 carat diamond'),
('necklace 6', '008', 'd necklace', 25000, '22 carat diamond '),
('necklace 7', '009', 'd necklace', 25000, '22 carat diamond'),
('necklace 8', '010', 'd necklace', 30000, '22 carat diamond '),
('necklace 9', '011', 'd necklace', 30000, '22 carat diamond'),
('necklace 10', '012', 'd necklace', 30000, '22 carat diamond '),
('ring 3', '013', 'gold rings', 20000, '24 carat gold plated'),
('ring 4', '014', 'gold rings', 25000, '24 carat gold plated'),
('d ring 1', '015', 'd ring', 30000, '22 carat diamond '),
('ring 6', '016', 'gold rings', 25000, '24 carat gold plated'),
('d ring 2', '017', 'd ring', 35000, '22 carat diamond'),
('d ring 3', '018', 'd ring', 30000, '22 carat diamond '),
('d ring 4', '019', 'd ring', 35000, '22 carat diamond'),
('ring 10', '020', 'gold rings', 30000, '24 carat gold plated'),
('ring 11', '021', 'gold rings', 30000, '24 carat gold plated'),
('d ring 4', '022', 'd ring', 35000, '22 carat diamond '),
('d ring 5', '023', 'd ring', 40000, '22 carat diamond'),
('d ring 6', '024', 'd ring', 40000, '22 carat diamond '),
('d ring 7', '025', 'd ring', 40000, '22 carat diamond'),
('d ring 8', '026', 'd ring', 50000, '22 carat diamond ');

-- --------------------------------------------------------

--
-- Table structure for table `useraccount`
--

CREATE TABLE IF NOT EXISTS `useraccount` (
  `uid` varchar(8) NOT NULL,
  `pwd` varchar(10) NOT NULL,
  `atype` varchar(8) NOT NULL,
  `question` varchar(40) NOT NULL,
  `answer` varchar(40) NOT NULL,
  `mob_no` varchar(12) NOT NULL,
  `mail_id` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `useraccount`
--

INSERT INTO `useraccount` (`uid`, `pwd`, `atype`, `question`, `answer`, `mob_no`, `mail_id`) VALUES
('1zafar', '111', 'user', 'Your nick name?', 'his', '7789552255', 'za@gmail.com'),
('fathima', '111', 'admin', 'what is ur fvrt color?', 'black', '7624834870', 'fatimaakbarak@gmail.com'),
('fida', '888', 'user', 'Your nick name?', 'fatM', '7789552255', 'fida@gmail.com'),
('fiza', '123', 'user', 'Your nick name?', 'pija', '8975778559', 'fiza@gmail.com'),
('pavi', '123', 'user', 'Your nick name?', 'paav', '8277590080', 'pavi@gmail.com'),
('sowmya', '222', 'user', 'Your nick name?', 'sow', '9897878989', 'sowmyak@gmail.com'),
('sunita', '444', 'user', 'Favorite movie?', 'nun', '7887785888', 'suni@gail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `productinfo`
--
ALTER TABLE `productinfo`
 ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `useraccount`
--
ALTER TABLE `useraccount`
 ADD PRIMARY KEY (`uid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
