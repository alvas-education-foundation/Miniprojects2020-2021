<?php
	require('dbfun.php');
	session_start();
	$msg='';
	$msg2='';
	if(isset($_REQUEST['submit']))
	{
		$_SESSION['uid']=$_REQUEST['uid'];
		$uid=$_REQUEST['uid'];
		$pwd=$_REQUEST['pwd'];
		$type=$_REQUEST['atype'];
		if(checkaccount($uid,$pwd)==true)
		{
			if(checkaccount_type($uid,$type)==true)
			{
				if($type=='admin')
				{
					$_SESSION['uid']=$uid;
					header('location:admin.php');
				}
				elseif($type=='user')
				{
					$_SESSION['uid']=$uid;
					header('location:addcart.php');
				}
				else
					$msg2="<font color=white><b>Invalid Account Type For Given User ID</b></font>";
				
			}
			else
				$msg2="<font color=white><b>Invalid Account Type For Given User ID</b></font>";
		}
		else
		{
			$msg='<font color=white><b>invalid credentials</b></font>';
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<style>
		#div1 a{
			text-decoration: none;
			color: gold;
			font-size: 20px;
			padding: 10px 10px; 
			font-weight: bold;
		}
		#div1{
			
			height: 30px;
			padding: 10px 10px;
		}
		a{
			text-decoration: none;
			color: white;
			font-size: 18px;
			padding: 10px 10px; 
			
		}
		#div2{
			background-color: brown;
			height: 27px;
			padding: 10px 10px 10px 10px;
		}
		fieldset{
			width: 500px;
		}
	</style>
</head>
<body style="background-image: url(images/b.jpg);background-size: cover;">
	<div style = "width:100%"> 				 
            <center><h1><font color="gold">WELCOME TO THE JEWELLERY SHOP SYSTEM</font></h1></center>
            <div id="div1">               
	             |<a href="login.php">Login</a>|
	             <a href="aboutus.php">About Us</a>|           
	             <a href="contactus.php">Contact Us</a>|
	         <!--    <a href="logout.php">Logout</a>|-->
         	</div>
    </div>
        
	
		<p></p>
	<form name="form1" action="" method="get">
		<fieldset>
		<legend ><h1><font color=gold>Login Page</font> </h1></legend>
		<center><table>
			<tr>			
				<td><font color=white><b>User ID:</b></font></td>
				<td><input type="text" name="uid" value="" placeholder="enter user id"></td>
			</tr>
			<tr>
				<td><br><font color=white><b>Password:</b></font></td>
				<td><br><input type="password" name="pwd" value="" placeholder="enter the password"></td><br><br>
			</tr>
			<tr>
				<td><br><font color=white><b>Type:</b></font></td>
				<td><br><select name="atype">
					<option value=""></option>
					<option value="admin">admin</option>
					<option value="user">user</option><br>
				</select></td>
			<?php echo $msg; ?>
			</tr>	
		<tr>
		<td><br><input type="submit" name="submit" value="Login">
		<a href="register.php"><input type="button" name="register" value="Register"></a></td></tr>
		</table>
		<br><a href="forgotpwd.php">Forgot Password?</a>&nbsp;|
		<a href="editpwd.php">Change Password</a><br><br>
		</fieldset>
	</form>
	</center>
	<br><br><br><div id="div2">
            	<marquee direction="left" width="100%"><font size="5" color="gold">***********choose your desired jewellerys... To look good and feel good***********</font></marquee>
            </div>	
	</body>
</html>