<body style="background-image: url(images/a.jpg);background-size: cover;">
 
<BR><marquee direction="down" height="500"><font size="6" color="black">Logout successfully!!!</font></marquee>
<a href="login.php"><input type="button" value="Login" name=Login></a>
</BR>
</body>
</html>