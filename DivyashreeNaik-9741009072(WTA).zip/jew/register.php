<?php 
	require('dbfun.php');
	$msg='';
	$msg2='';
	$msg3='';
	if(isset($_REQUEST['register']))
	{
		$uid=$_REQUEST['uid'];
		$pwd=$_REQUEST['pwd'];
		$cpwd=$_REQUEST['cpwd'];
		$atype="user";
		$question=$_REQUEST['question'];
		$answer=$_REQUEST['answer'];
		$mob_no=$_REQUEST['mob_no'];
		$mail_id=$_REQUEST['mail_id'];
		
		if($pwd==$cpwd)
		{
			if(register($uid,$pwd,$atype,$question,$answer,$mob_no,$mail_id))
				$msg="<font color=gold><b>Registered Successfully</b></font>";
			else
				$msg="<font color=white><b>unsuccessfull Registration</b></font>";
		}
		else
			$msg2="<font color=white><b>Confirm Password does Not Match the Password</b></font>";
		
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body style="background-image: url(images/c.jpg);background-size: cover;">
	<center>
		
	<form name="form2" action="" method="get">
		<h1><font color="gold">Registration Page</font></h1>
		<table>
			<tr>
				<td><font color=gold><b>User Id:</b></font></td>
				<td><input type="text" name="uid" value="" placeholder="enter user id"required/></td>
			</tr>
			
			<tr>
				<td><br><font color=gold><b>Password:</b></font></td>
				<td><br><input type="password" name="pwd" value="" placeholder="enter password"required/></td>
			</tr>
			<tr>
				<td><br><font color=gold><b>Confirm Password:</b></font></td>
				<td><br><input type="password" name="cpwd" value="" placeholder="enter Confirm password" required/></td>
			</tr>
			<tr>
				<td><br><font color=gold><b>Select Security Question:</b></font></td>
				<td><br><select name="question" required/>
				<option value=""></option>
  				<option value="Name of the first school you studied?">Name of the first school you studied?</option>
  				<option value="Your nick name?">Your nick name?</option>
  				<option value="Favorite movie?">Favorite movie?</option>
  				<option value="Best friends name?">Best friends name?</option>
			</select></td>
			</tr>
			<tr>
				<td><br><font color=gold><b>Answer For The Security Question:</b></font></td>
				<td><br><input type="text" name="answer" value="" placeholder="enter your answer"required/></td>
			</tr>
			<tr>
				<td><br><font color=gold><b>Mobile Number:</b></font></td>
				<td><br><input type="text" name="mob_no" value="" pattern="^\d{10}$" placeholder="enter valid mobile no"></td>
			</tr>
			<tr>
				<td><br><font color=gold><b>Mail ID:</b></font></td>
				<td><br><input type="text" name="mail_id" value="" pattern="[^@]*@[^@]*" placeholder="enter email-id"></td>
			</tr>
			
		<tr>
		<td><br><a href="login.php"><input type="button" name="back" value="Back"></a>&nbsp;&nbsp;&nbsp;&nbsp;
		<input type="submit" name="register" value="Register"></td>
		</tr>
		<tr><td></td>
			<td><span><?php echo $msg; ?>
				<?php echo $msg2; ?>
			</span></td>
		</tr>
		</table>
	</form>
	</center>
</body>
</html>