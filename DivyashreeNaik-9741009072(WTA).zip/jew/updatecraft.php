<?php 
	require('dbfun.php');
	$msg='';
	$msg2='';
	$msg3='';
	$craftdet=array("","","","","","","","","","","","","","");
	$msg1="";
	if(isset($_REQUEST['show']))
	{
		$pid=$_REQUEST['pid'];
		//$pwd=$_REQUEST['pwd'];
		if(checkcraft($pid)==true)
		{
           $msg3="<font color=gold><b>enter craft id to update</b></font>";
			$craftdet= getCraftDetails($pid);
	    }
		else
			$msg="invalid credentials";
	}
        if(isset($_REQUEST['update']))
	{
		$pname=$_REQUEST['pname'];
		$pid=$_REQUEST['pid'];
		$category=$_REQUEST['category'];
		//$type="user";
		$price=$_REQUEST['price'];
		$prod_det=$_REQUEST['prod_det'];
		
			if(updatecraft($pname,$pid,$category,$price,$prod_det))
				$msg="<font color=gold><b>Updated Successfully</b></font>";
			else
				$msg="<font color=white><b>Updation is Unsuccessfull</b></font>";	
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Craft</title>
</head>
<body style="background-image: url(images/d.jpg);background-size: cover;">
	<center>
	<form name="form2" action="" method="get">
		<h1><font color="gold">Update details</font></h1>
		<table>
			<tr>
				<td><font color="gold"><b>Jewellery ID:</b></font></td>
				<td><input type="text" name="pid" value="<?php if(isset($_REQUEST['pid'])) echo $_REQUEST['pid'] ?>" required></td><td><input type="submit" name="show" value="Submit pid "></td>
				</tr>
			<tr>
			<td><span><?php echo $msg3; ?>
				<?php echo $msg2; ?>
                
			</span></td></td></tr>
			<tr>
				<td><font color="gold"><b>Jewellery Name:</b></font></td>
				<td><input type="text" name="pname" value='<?php echo $craftdet[0]; ?>' ></td>
			</tr>
			<tr>
				<td><font color="gold"><b>Catagory:</b></font></td>
				<td><select name="category">
					<option value=""></option>
  				<option value="gold rings">gold rings</option>
  				<option value="d necklace">d necklace</option>
  				<option value="d ring">d ring</option>
			</select></td>
			</tr>
			<tr>
				<td><font color="gold"><b>Price:</b></font></td>
				<td><input type="text" name="price" value='<?php echo $craftdet[3]; ?>' ></td>
			</tr>
			<tr>
				<td><font color="gold"><b>Jewellery details:</b></font></td>
				<td><input type="text" name="prod_det" value='<?php echo $craftdet[4]; ?>' ></td>
			</tr>
			<tr>
		<td><a href="admin.php"><input type="button" name="back" value="Back"></a>&nbsp;&nbsp;&nbsp;&nbsp;
		<input type="submit" name="update" value="Update"></td>
		</tr>
		<tr><td></td>
			<td><span><?php echo $msg; ?>
         
			</span></td>
		</tr>
		</table>
	</form>
	</center>
</body>
</html>