<footer>
    <div id="sec"><a href="adminlogin.php">Admin Login</a><hr color="#95A5A6">
    </div>
    <div id="sec"><a href="aboutus.php">About Us</a><hr color="#95A5A6">
    </div>
    <div id="sec"><a href="feedback.php">Feedback</a><hr color="#95A5A6">
    </div>
</footer>
<style>
    a{ color: #95A5A6;}
    footer{
        position: absolute;
        bottom:0px;
        left: 0px;
        width:100%;
        color:rgb(0, 0, 12);
        border-radius: 30px;
        background-color: rgba(83, 33, 73, 0.938);}
    #sec{
        float: left;
        width:30%;
        padding-top: 10px;
        padding-left: 8px;
        padding-right: 8px;
    }
</style>