<?php
include('header.php');
include('sidebar.php');
?>  


<div id="page-wrapper">
  <div class="graphs">
    <h3>Welcome to Admin panel</h3>
  </div>
  <!--body wrapper start-->
</div>
<!--body wrapper end-->
</div>

<?php
include('footer.php');
?>