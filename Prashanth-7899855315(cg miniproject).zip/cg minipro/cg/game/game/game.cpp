// game.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<GL/glut.h>
int x[4]={130,160,190,220};
int y[5]={10,40,70,100,130};
int dx1[3]={-110,0,110};
static int dy=1300,dx=0,opp=1,r=1,l=1,f=0,crash=0;
static int y1=0,s=0,c=0,level=0,gm=1,fl=1,last=1,exe=0;
static float score=0.08;
int i,j,n=60,nx[4],ny[5];
char sp[9]={'S','c','o','r','e',':',' '};
void *currentfont;

void setFont(void *temp)
{
	currentfont=temp;
}

void drawstring(GLfloat x,GLfloat y,char *textstring)
{
    int le;
    int qs;
    glRasterPos2f(x, y);
    le=strlen(textstring);
    for(qs=0;qs<le;qs++)
		glutBitmapCharacter(currentfont,textstring[qs]);
}

void start()
{
	setFont(GLUT_BITMAP_TIMES_ROMAN_24);
	drawstring(50,500,"START GAME");
	setFont(GLUT_BITMAP_8_BY_13);
	drawstring(89,450,"SELECT  LEVEL");
	drawstring(100,400,"1    2    3");
	drawstring(100,350,"4    5    6");
}

void sidelines(int y)
{
	glBegin(GL_POLYGON);
	glVertex2i(0,y);
	glVertex2i(0,y+100);
	glVertex2i(10,y+100);
	glVertex2i(10,y);
	glEnd();
	glBegin(GL_POLYGON);
	glVertex2i(340,y);
	glVertex2i(340,y+100);
	glVertex2i(350,y+100);
	glVertex2i(350,y);
	glEnd();
}

void car_draw(int dx1,int dy1)
{
	int flag=0;
	for(i=0;i<4;i++)nx[i]=x[i]+dx1;
	for(i=0;i<5;i++)ny[i]=y[i]+dy1;
	for(i=0;i<3;i++)
	{
		for(j=0;j<4;j++)
		{
			if(flag%2==0)
			{
				glBegin(GL_POLYGON);
				glVertex2i(nx[i],ny[j]);
				glVertex2i(nx[i],ny[j+1]);
				glVertex2i(nx[i+1],ny[j+1]);
				glVertex2i(nx[i+1],ny[j]);
				glEnd();
			}
			flag++;
		}
		flag++;
	}
}

void display()
{
	if(opp==1)
	{
		f=rand()%3;
		opp=0;
	}
	glClear(GL_COLOR_BUFFER_BIT);
	if(s==0)
		start();
	glColor3f(1.0,0.0,0.0);
	if(crash)
	{
		drawstring(50,300,"- - CRASH - -");
		crash=0;
	}
	car_draw(dx,0);
	if(last)
	{
		sp[6]=(score/1000)+'0';
		sp[7]=(((int)score%1000)/100)+'0';
		sp[8]=(((int)score%100)/10)+'0';
		sp[9]=((int)score%10)+'0';
		score+=(s*0.08);
		setFont(GLUT_BITMAP_8_BY_13);
		if(s)drawstring(20,650,sp);
		glColor3f(1.0,1.0,0.0);
		car_draw(dx1[f],dy);
		car_draw(dx1[(f+2)%3],dy-400);
	}
	glColor3f(1.0,1.0,1.0);
	for(i=0;i<200000;i+=200)sidelines(y1+i);
	setFont(GLUT_BITMAP_TIMES_ROMAN_24);
	if(c==4)
	{
		drawstring(120,600,"GAME");
		drawstring(125,550,"OVER");
		setFont(GLUT_BITMAP_8_BY_13);
		drawstring(120,500,sp);
	}
	if(gm)
	{
		glutSwapBuffers();
		gm--;
	}
	if(c==3)
	{
		last=0;
		c++;
		gm=2;
		dy=2000;
		dx=0;
		l=r=1;
	}
}

void wait(int v)
{
	if(exe!=c)
	{
		dy=1300;
		exe++;
	}
	if(dy<=-100)
	{
		dy=1300;
		opp=1;
		level++;
	}
	for(i=s*4;i>0;i--)
	{
		if(c<=3)
		{
			dy-=1;
			gm+=2;
		}
		if((dy==120 && dx==dx1[f]) || ((dy-400)==120 && dx==dx1[(f+2)%3]))
		{
			crash=1;
			c++;
			fl=0;
		}
	}
	if(((x[1]+dx1[(f+2)%3])>=(x[0]+dx) && (x[2]+dx1[(f+2)%3])<=(x[3]+dx)) && ((y[2]+(dy-400))>=y[0] && (y[3]+(dy-400))<=y[4]))
	{
		crash=1;
		c++;
		fl=0;
	}
	if(((y[2]+dy)>=y[0] && (y[3]+dy)<=y[4]) && ((x[1]+dx1[f])>=(x[0]+dx) && (x[2]+dx1[f])<=(x[3]+dx)))
	{
			crash=1;
			c++;
			fl=0;
	}
	if(level==10*s && s!=0)
	{
		s++;
		level=0;
		dy=1100;
		fl=0;
	}
	if(c<=3 && fl!=0)
		y1-=s*6;
	if(fl)
		glutTimerFunc(10,wait,v);
	else
	{
		glutTimerFunc(2000,wait,v);
		fl=1;
	}
	glutPostRedisplay();	
}

void keyboard(int key,int x,int y)
{
	switch(key)
    {
		case GLUT_KEY_LEFT:
			if(l>0)
			{
				l--;r++;
				dx-=110;	//change car plane
			}
			break;
		case GLUT_KEY_RIGHT:
			if(r>0)
			{
				r--;l++;
				dx+=110;
			}
			break;
	}
}

void mouse(int btn,int state,int x,int y)
{
	if(s==0)
	if(state==GLUT_DOWN)
		if(btn==GLUT_LEFT_BUTTON)
		{
			if(x>=24 && x<=190)
				if(y>=94 && y<=118)s=1;
			if(y>=160 && y<=170)
			{
				if(x>=59 && x<=70)s=1;
				if(x>=99 && x<=110)s=2;
				if(x>=139 && x<=150)s=3;
			}
			if(y>=190 && y<=200)
			{
				if(x>=59 && x<=70)s=4;
				if(x>=99 && x<=110)s=5;
				if(x>=139 && x<=150)s=6;
			}
			fl=0;
		}
}

void myinit()
{
	gluOrtho2D(0,350,0,700);
	glClearColor(0.0,0.0,0.0,1.0);
}

void main(int argc,char **argv)
{
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(215,400);
	glutInitWindowPosition(750,100);
	glutCreateWindow("MOTORSPORT");
	glutDisplayFunc(display);
	glutTimerFunc(1000,wait,n);
	glutMouseFunc(mouse);
	glutSpecialFunc(keyboard);
	myinit();
	glutMainLoop();
}