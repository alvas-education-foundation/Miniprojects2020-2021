<?php

require 'db_connect.php';
require 'ext.php';
require 'nav.php';
?>
<html>
<head>
<title>About</title>
</head>
  <style>
    body{
      background-color:cadetblue;
    }
  </style>
  <body>
  <p>
    Home appliances is your expert and is proud to be serving to you all time.Just come-in and experience personalized one-on-one service in our site.We are your source for competitve prices with knowledge in store-professionals here to help every step of the way.We will work with you to fimg a product that fits yoyr needs ,budget,lifestyle. 
    
    </p>
    <h2>Contact US</h2>
    <b><p>9765409762</b><br>
     <b>908767675</b><br>
  <b>Email:homeapplicance@gmail.com</b>
    </p>
  
  </body>