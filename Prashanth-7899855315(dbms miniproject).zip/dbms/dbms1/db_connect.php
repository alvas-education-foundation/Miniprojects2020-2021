<?php

$conn=mysqli_connect('localhost','root','','homesales');
if(mysqli_connect_errno()){
    mysqli_connect_errno();
}
?>