<?php
$con=mysqli_connect("localhost","root","","shop") or die(mysqli_error($con));
//$con=mysqli_connect("localhost","root","","shop") or die(mysqli_error($con));
?>
