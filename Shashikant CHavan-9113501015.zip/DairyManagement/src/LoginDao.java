import java.sql.*;
public class LoginDao 
{
	public boolean checklog(String uname, String pass)
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/dairy", "root", "2308");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("Select * from register where Username='"+uname+"' and Password='"+pass+"';");
			if(rs.next())
			{
				return true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return false;
	}
}
