

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet("/PrintDetails")
public class PrintDetails extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try 
		{
			int carid=Integer.parseInt(request.getParameter("carid"));
			PrintWriter out=response.getWriter();
			out.println("<html><body>");
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/dairy", "root", "2308");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("Select * from vehicles where vehicleid="+carid+";");
		out.println("<table border=1");
		out.println("<tr><th>Vehicleid</th><th>Vehicle Name</th><th>Model</th><th>Owner PhoneNo</th><th>Rental Price(Rs)</th></tr>");
		while(rs.next())
		{
			int vid=rs.getInt("vehicleid");
			String name=rs.getString("company");
			String model=rs.getString("model");
			String owner=rs.getString("ownerphone");
			int rent=rs.getInt("rentprice");
			out.println("<tr><td>"+vid+"</td><td>"+name+"</td><td>"+model+"</td><td>"+owner+"</td><td>"+rent+"</td></tr>");
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
