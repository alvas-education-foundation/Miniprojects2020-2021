import java.sql.*;
public class RegisterDao
{

	public void insertcust(InsertCust ic) 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/dairy", "root", "2308");
			PreparedStatement ps=con.prepareStatement("insert into register values(?,?,?,?,?,?,?,?,?)");
			ps.setString(1, ic.getUsername());
			ps.setString(2, ic.getDlno());
			ps.setString(3, ic.getAddress());
			ps.setString(4, ic.getCity());
			ps.setString(5, ic.getState());
			ps.setString(6, ic.getPin());
			ps.setString(7, ic.getEmail());
			ps.setString(8, ic.getPhone());
			ps.setString(9, ic.getPass());
			ps.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
