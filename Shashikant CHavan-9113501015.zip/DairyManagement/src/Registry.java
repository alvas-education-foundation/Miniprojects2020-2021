
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Registry")
public class Registry extends HttpServlet 
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	
		InsertCust ic=new InsertCust();
		ic.setUsername(request.getParameter("un"));
		ic.setAddress(request.getParameter("address"));
		ic.setCity(request.getParameter("city"));
		ic.setState(request.getParameter("state"));
		ic.setPin(request.getParameter("pin"));
		ic.setEmail(request.getParameter("email"));
		ic.setPhone(request.getParameter("phone"));
		ic.setPass(request.getParameter("pass"));
		RegisterDao rdao=new RegisterDao();
		rdao.insertcust(ic);
		response.sendRedirect("Login.jsp");
	}
}
