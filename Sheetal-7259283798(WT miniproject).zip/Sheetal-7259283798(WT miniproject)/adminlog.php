<?php

  $name = $_POST["Admin_name"];
 $Password =$_POST["Password"];

$link = mysqli_connect("localhost", "root", "", "BANK"); 
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }                                                                   
    $sql = select * from ADMIN;
        if(mysqli_query($link, $sql)){
            if($row['Name']==$Name && $row['Password']==$PAssword)
            {
                
            }
        echo "Records added successfully.";
        
        echo "<h2>Your Details:</h2>";
 
    }
else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

   

    mysqli_close($link);                                                                                          
?>