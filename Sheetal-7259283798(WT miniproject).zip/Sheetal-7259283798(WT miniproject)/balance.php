
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
    background-color:LightBlue;
}

tr:nth-child(even) {
    background-color:fuchsia;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>online bank</title>

</head>
<body>
<?php
    $res1="";
  $Acc_no = $_POST["Acc_no"];
    $Password= $_POST["Password"];
    $Cust_name =$_POST["Cust_name"];
		
    $link = mysqli_connect("localhost", "root", "", "BANK"); 
    $sql = "select * from ACCOUNT a inner join CUSTOMER c on a.CustId=c.CustId where Acc_Id='$Acc_no'and Password='$Password' and a.Custname='$Cust_name'";
    
    if($result=mysqli_query($link, $sql)){
        while($row = mysqli_fetch_array($result)){
           
        $res1=$row['Balance'];
        
             }
    }
else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }
    ?>
			
			<table align="center" cellspacing='5' cellpadding='5' style="width:30%;padding-top: 12px;
    padding-bottom: 12px;
    text-align:left;
    background-color:LightCoral;
    color: white;">
			<B><tr><th>BALANCE : <?php echo $res1?></th></B>
           
						</table></body>
</html>