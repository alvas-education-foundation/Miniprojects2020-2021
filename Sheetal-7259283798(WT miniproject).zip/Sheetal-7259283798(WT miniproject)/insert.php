<html>
<head>
<style>
table,td,th{
border: 1px solid black;
width:20px;
background-color: lightblue;
    border-collapse: collapse;
text-align:left;
}
    table{
        margin: auto;
    }
    </style>    
    </head>
<?php

$Cust_name = $Address = $Phone_no = $Acc_Id = $Acc_type= "";

  $Cust_name = $_POST["Cust_name"];
  $Address = $_POST["Address"];
    $Gender=$_POST["gender"];
  $Phone_no =$_POST["Phone_no"];
 $Password =$_POST["Password"];
 $Repassword =$_POST["Repassword"];
     $Acc_type =$_POST["Acc_type"];
    $Amount =$_POST["Amount"];

  
$link = mysqli_connect("localhost", "root", "", "BANK"); 
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
                                                                        
    $sql = "INSERT INTO CUSTOMER(Custname,Password,Repassword, Address, Phone,AccountType,Amount,Gender) VALUES ('$Cust_name',$Password, $Repassword,'$Address', '$Phone_no','$Acc_type','$Amount','$Gender')";
       if(mysqli_query($link, $sql)){
        echo "<center><h2>Account Created successfully.</h2></center>";
        
        echo "<center><h2>Your Details:</h2></center>";
echo "<center>";
echo "<table border=1>";
echo "<tr><td>Name:"."<td>".$Cust_name."</td>"."</td></tr>";
echo "<br>";
echo "<tr><td>Gender:"."<td>".$Gender."</td>"."</td></tr>";
echo "<br>";
echo "<tr><td>Address:"."<td>".$Address."</td>"."</td></tr>";
echo "<br>";
echo "<tr><td>Phone Number:"."<td>".$Phone_no."</td>"."</td></tr>";
echo "<br>";
echo "<tr><td>Account Type:"."<td>".$Acc_type."</td>"."</td></tr>"; 
echo "<br>";
echo "<tr><td>Amount:"."<td>".$Amount."</td>"."</td></tr>";
echo "<br>";
echo "</table></center>";
 
    }
else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }

     $link1 = mysqli_connect("localhost", "root", "", "BANK"); 
    $sql1= "select * from ACCOUNT where Custname='$Cust_name'";
    if($result = mysqli_query($link1, $sql1)){
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_array($result)){
//            echo "<br/><br/><br/><br/>";
            echo "<center><h2>Your Account No : </h2>"."<h2>".$row['Acc_Id']."</h2></center>";
        }
    }
    }
else{
        echo "ERROR: Could not able to execute $sql1. " . mysqli_error($link1);
    }

    mysqli_close($link); 
   mysqli_close($link1); 
                                                                                         
?>
</html>