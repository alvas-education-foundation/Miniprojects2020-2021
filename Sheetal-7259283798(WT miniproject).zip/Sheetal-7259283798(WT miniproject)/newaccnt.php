<!DOCTYPE HTML>
<html>
<head>
<title>online bank</title>

   </head>
   

<body style="background-image: url(bank.jpg); background-size:cover">
 
         
       <A href="home.html"><IMG SRC="homebank.jpg"></IMG></A>	 
    <h2 style="text-align: center; color:white">NEW ACCOUNT FORM</h2><br>
    	    <table  align="center" bgcolor="white">
		<tr>
			<td>
                

				<form name="F1" 
				onSubmit="return dil(this)"
	method="POST"
	action="insert.php">
				  <table cellspacing="5" cellpadding="3" style="width:500px;height:300px;"'>	
				    
				    
					<tr><td>FULL NAME:</td><td> <input type="text"  name="Cust_name" required=""  /></td></tr>
					<tr><td>ADDRESS:</td><td> <input type="text" name="Address" required=""/></td></tr>
					<tr><td>PHONE:</td><td> <input type="text" name="Phone_no"  required/></td></tr>
                    <tr><td>GENDER:</td><td> <input type="radio" name="gender" value="male" checked> Male <input type="radio" name="gender" value="female"> Female<br></td></tr>
                    <tr><td>PASSWORD:</td><td> <input type="password" name="Password" required=""/></td></tr>                                <tr><td>RE-PASSWORD:</td><td> <input type="password" name="Repassword" required=""/></td></tr>                         
				    <tr><td>ACCOUNT TYPE:</td><td> <select name="Acc_type" required=""/>
												
                                                     <option value="current">Current</option>
                                                    <option value="Fixed">Fixed</option>
                                                    <option value="savings">Savings</option>
                                                    </select></td></tr>
								<tr><td>AMOUNT:</td><td> <input type="text" name="Amount" required=""/></td></tr>
					<tr><td></td><td><input type="submit" value="Submit"/>
					
					<INPUT TYPE=RESET VALUE="CLEAR"></td></tr>
					</table>
               		</form>

			</td>
		</tr>
	</table>
	</body>
	</html>