
<!DOCTYPE html">
<html>
<head>
<title>online bank</title>
<style type="text/css">
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
    background-color:LightBlue;
}

tr:nth-child(even) {
    background-color: fuchsia;
}
</style>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Insert title here</title>

</head>
<body>
<?php

  $Acc_no = $_POST["Acc_no"];
  $Cust_name=$_POST["Cust_name"];
  $Password= $_POST["Password"];
    $TAcc_no=$_POST["TAcc_no"];
    $Balance =$_POST["Balance"];
    $link = mysqli_connect("localhost", "root", "", "BANK"); 
    $sql = "select * from ACCOUNT where Acc_Id='$TAcc_no' ";  
    if($result=mysqli_query($link, $sql)){
        while($row = mysqli_fetch_array($result)){
           
        $res=$row['Balance']+$Balance;
        
             }
    }
    else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }
     $link1 = mysqli_connect("localhost", "root", "", "BANK"); 
    $sql1="update ACCOUNT SET Balance='$res' where Acc_Id='$TAcc_no'";
    if(mysqli_query($link1, $sql1)){
        echo "<br>";
    }
    else{
        echo "ERROR: Could not able to execute $sql1. " . mysqli_error($link1);
    }
    
    
     $link2 = mysqli_connect("localhost", "root", "", "BANK"); 
    $sql2 = "select * from ACCOUNT a inner join CUSTOMER c on a.CustId=c.CustId where Acc_Id='$Acc_no'and Password='$Password' ";
    if($result=mysqli_query($link2, $sql2)){
        while($row = mysqli_fetch_array($result)){
           $res1="";
        $res1=$row['Balance']-$Balance;
        
             }
    }
    else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link2);
    }
     $link3 = mysqli_connect("localhost", "root", "", "BANK"); 
    $sql3="update ACCOUNT SET Balance='$res1' where Acc_Id='$Acc_no'";
    if(mysqli_query($link3, $sql3)){
        echo "<center><h2>Amount Transferred successfully.</h2></center>";
        echo "<br>";
    }
    else{
        echo "ERROR: Could not able to execute $sql3. " . mysqli_error($link3);
    }
    
    ?>
	<table align="center" cellspacing='5' cellpadding='5' style="width:30%;padding-top: 12px;
    padding-bottom: 12px;
    text-align:left;
    background-color:LightCoral;
    color: white;">
			<B><tr><th>ACCOUNT NO</th><th> NEW BALANCE</th></tr></B>
           <tr> <td> <?php echo $Acc_no?></td><td> <?php echo $res1?></td></tr>
						</table>
</body>
</html>