
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>online bank</title>
<style type="text/css">
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>online bank</title>

</head>
<body>
<?php
  $Acc_no = $_POST["Acc_no"];
    $Password= $_POST["Password"];
    $Balance1 =$_POST["Balance"];
		
    $link = mysqli_connect("localhost", "root", "", "BANK"); 
    $sql = "select * from ACCOUNT a inner join CUSTOMER c on a.CustId=c.CustId where Acc_Id='$Acc_no'and Password='$Password'";
    $dataamount= 0;
    
    if($result=mysqli_query($link, $sql)){
        while($row = mysqli_fetch_array($result)){
           
        $res=$row['Balance']-$Balance1;
        
             }
    }
else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
    }
     $link1 = mysqli_connect("localhost", "root", "", "BANK"); 
    $sql1="update ACCOUNT SET Balance='$res' where Acc_Id='$Acc_no'";
    if(mysqli_query($link1, $sql1)){
        echo "<center><h2>Amount Withdrawed successfully.</h2></center>";
        echo "<br>";
        echo "<br>";
    }
    else{
        echo "ERROR: Could not able to execute $sql1. " . mysqli_error($link1);
    }
    
    ?>
			
			<table align="center" cellspacing='5' cellpadding='5' style="width:30%;padding-top: 12px;
    padding-bottom: 12px;
    text-align:left;
    background-color:LightCoral;
    color: white;">
			<B><tr><th>NEW BALANCE : <?php echo $res ?></th></B>
           
						</table>
</body>
</html>