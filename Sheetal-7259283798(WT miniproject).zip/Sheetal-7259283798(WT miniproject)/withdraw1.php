<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>online bank</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>online bank</title>
</head>
<body style="background-image: url(images/bankbackgrnd.jpg); background-size:cover">
 <A href="homeBank.html"><IMG SRC="images/homebank.jpg"></IMG></A>	 

    	<div align="center"  style="border-right:#666666 1px dotted;color:white;"><h1>WITHDRAW FORM</h1><br></div>
    	    <table  align="center" bgcolor="white">
		<tr>
		
		</tr>
		<tr>
			<td><div><%if(request.getAttribute("Balance")!=null)
			{
			out.print(request.getAttribute("Balance"));
			}
			
			 %></div>
				<form name="F1" 
				onSubmit="return dil(this)"
	             method="post"
	              action="withdraw.jsp">
				    <table cellspacing="5" cellpadding="3">
				    <tr><td>ACCOUNT NO:</td><td> <input type="text" name="Acc_no"/></td></tr>
				     <tr><td>USER NAME:</td><td> <input type="text" name="Cust_name"/></td></tr>
					<tr><td>PASSWORD:</td><td> <input type="password" name="Password"/></td></tr>	
					<tr><td>AMOUNT:</td><td> <input type="text" name="Balance"/></td></tr>					
					<tr><td></td><td><input type="submit" value="Submit"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<INPUT TYPE=RESET VALUE="CLEAR"></td></tr>
                   	</table>	
				</form>
		
</body>
</html>