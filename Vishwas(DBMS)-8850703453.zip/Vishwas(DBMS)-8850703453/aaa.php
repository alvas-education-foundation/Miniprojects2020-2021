<html>
<title></title>
<body></body>
</html>
<?php
session_start();
include_once('connect_db.php');
if(isset($_SESSION['username'])){
$id=$_SESSION['admin_id'];
$username=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/index.php");
exit();
}
if(isset($_POST['submit'])){
$fname=$_POST['first_name'];
if (!preg_match("/^[a-zA-Z ]*$/",$fname))
  {
  $nameErr = "Only letters and white space allowed";
  }
$sql='call getcashier()';
    while($aa=mysql_fetch_assoc($sql)==TRUE)
    {
        echo $aa[0];
    }
?>
