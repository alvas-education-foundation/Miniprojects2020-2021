 <?php
	session_start();
	if($_SESSION['user']){
	}
	else{
		header("location:index.php");
	}
	if($_SERVER['REQUEST_METHOD'] = "POST") //Added an if to keep the page secured
	{
		$name = mysql_real_escape_string($_POST['name']);
		$dob = mysql_real_escape_string($_POST['dob']);
		$emailid = mysql_real_escape_string($_POST['emilid']);
		$coursename = mysql_real_escape_string($_POST['coursename']);
		//$decision ="no";
		mysql_connect("localhost", "root","") or die(mysql_error()); //Connect to server
		mysql_select_db("first_db") or die("Cannot connect to database"); //Connect to database
		//foreach($_POST['public'] as $each_check) //gets the data from the checkbox
 		//{
 			//if($each_check !=null ){ //checks if the checkbox is checked
 			//	$decision = "yes"; //sets teh value
 			//}
 		//}
		
		mysql_query("INSERT INTO list_t (name, dob, emailid, coursename) VALUES ('$name','$dob','$emailid','$coursename')"); //SQL query
		header("location: home_t.php");
	}
	else
	{
		header("location:home_t.php"); //redirects back to hom
	}
?>