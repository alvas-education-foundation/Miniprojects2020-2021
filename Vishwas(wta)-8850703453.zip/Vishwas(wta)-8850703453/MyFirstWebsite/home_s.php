<html>
	<head>
		<title>My first PHP website</title>
	</head>
	<?php
	session_start(); //starts the session
	if($_SESSION['user']){ //checks if user is logged in
	}
	else{
		header("location:index.php"); // redirects if user is not logged in
	}
	$user = $_SESSION['user']; //assigns user value
	?>
	<body>
		<h2>Student page</h2>
		<p>Hello <?php Print "$user"?>!</p> <!--Displays user's name-->
		<a href="logout.php">Click here to logout</a><br/><br/>
		<form action="add_s.php" method="POST">
		    Name: <input type="text" name="name"/><br/>
			DOB: <input type="text" name="dob"/><br/>
			Email id: <input type="text" name="emailid"/><br/>
			Add course: <input type="text" name="coursename"/><br/>
			<!--public post? <input type="checkbox" name="public[]" value="yes"/><br/>-->
			<input type="submit" value="Add to list"/>
		</form>
		<h2 align="center">My list</h2>
		<table border="1px" width="100%">
			<tr>
			    <th>Id</th>
			    <th>Name</th>
				<th>DOB</th>
				<th>Email id</th>
				<th>Course names</th>
				<th>Edit</th>
				<th>Delete</th>
				<!--<th>Public Post</th>-->
			</tr>
			<?php
				mysql_connect("localhost", "root","") or die(mysql_error()); //Connect to server
				mysql_select_db("first_db") or die("Cannot connect to database"); //connect to database
				$query = mysql_query("Select * from list_s"); // SQL Query
				while($row = mysql_fetch_array($query))
				{
					Print "<tr>";
						Print '<td align="center">'. $row['id'] . "</td>";
						Print '<td align="center">'. $row['name'] . "</td>";
						Print '<td align="center">'. $row['dob']."</td>";
						Print '<td align="center">'. $row['emailid']. "</td>";
						Print '<td align="center">'. $row['coursename']. "</td>";
						Print '<td align="center"><a href="edit_s.php?id='. $row['id'] .'">edit</a> </td>';
						Print '<td align="center"><a href="#" onclick="myFunction('.$row['id'].')">delete</a> </td>';
						//Print '<td align="center">'. $row['public']. "</td>";
					Print "</tr>";
				}
			?>
		</table>
		<script>
			function myFunction(id)
			{
			var r=confirm("Are you sure you want to delete this record?");
			if (r==true)
			  {
			  	window.location.assign("delete_s.php?id=" + id);
			  }
			}
		</script>
	</body>
</html>