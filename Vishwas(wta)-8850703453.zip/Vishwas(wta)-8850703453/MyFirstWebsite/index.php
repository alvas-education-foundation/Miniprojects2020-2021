<html>
    <head>
        <title>My first PHP Website</title>
    </head>
    <body bgcolor="khaki">
        <?php
            echo "<p><h1><center>ONLINE COURSES MANAGEMENT SYSTEM</h1></center></p>";
        ?>
		<a href="register.php"> Click here to register <br><br>
        <a href="login.php"> Click here to login as Admin <br><br>
		<a href="login_s.php"> Click here to login as Student<br><br>
		<a href="login_t.php"> Click here to login as Teacher
        
    </body>
</html>