<html>
	<head>
		<title>My first PHP website</title>
	</head>
	<body>
		<h2> Student Login Page</h2>
		<a href="index.php">Click here to go back</a><br/><br/>
		<form action="checklogin_s.php" method="post">
			Enter Username: <input type="text" name="username" required="required"/> <br/>
			Enter Password: <input type="password" name="password" required="required" /> <br/>
			<input type="submit" value="Login"/>
		</form>
	</body>
</html>