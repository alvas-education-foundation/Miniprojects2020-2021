           <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>  <br><br>
                            <li class="has_sub">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Dashboard </span> </a>
                         
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Student Details </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-category.php">Add Student</a></li>
                                    <li><a href="manage-categories.php">Manage Student</a></li>
                                </ul>
                            </li>
                            <!--  <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Report </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="generate-tc.php">TC</a></li>
                                   <li><a href="manage-categories.php">Study Certificate</a></li>
                                </ul>
                            </li>-->

    

                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                    <div class="help-box">
                        <h5 class="text-muted m-t-0">For Help ?</h5>
                        <p class=""><span class="text-custom">Email:</span> <br/>Manojhennagara@gmail.com</p>
                    </div>

                </div>
                <!-- Sidebar -left -->

            </div>