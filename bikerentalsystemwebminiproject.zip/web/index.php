<?php
if(isset($_POST['submit'])){

    //collect form data
    $count=80;
    $name = $_POST['name'];
    $address = $_POST['address'];
    #$mobileno = $_POST['mobileno'];
    $email = $_POST['email'];
   # $message = $_POST['message'];
    

    //if no errors carry on
    if(!isset($error)){

        // Title of the CSV
              echo"\t\t\tYour Booking details\n";
              $Content = "Booking_ID\tName\t\tEmail\t\t\t\tAddress\n";

        //set the data of the CSV
        $randomNumber = rand(100,1180); 
        $Content .= "$randomNumber\t\t$name\t\t$email\t\t$address";

        //set the file name and create CSV file
        $FileName = $name."-".date("d-m-y-h:i:s").".txt";
        header('Content-Type: application/csv'); 
        header('Content-Disposition: attachment; filename="' . $FileName . '"');
    
        echo $Content;
        exit();
    }
}

//if their are errors display them
if(isset($error)){
    foreach($error as $error){
        echo '<p style="color:#ff0000">$error</p>';
    }
}
//**********************EMAIL*******************
if(isset($_POST['Submit'])){

$Email = $_POST['mail'];
   echo"<h1>Thank you for contacting us,We will get in touch with you soon</h1>"; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Bike Rentel System </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Motorbike Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all"> 
<link href="css/font-awesome.css" rel="stylesheet"> <!-- font-awesome icons -->
<link rel="stylesheet" href="css/lightbox.css">
<!--//Custom Theme files-->
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script>  
<!-- //js -->
<!-- web-fonts -->
<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Arsenal:400,400i,700,700i" rel="stylesheet"> 
<!-- //web-fonts --> 
</head> 
<body> 
	<!-- banner -->
	<div id="home" class="banner">
		<div class="banner-agileinfo">
			<!-- header -->
			<div class="header">
				<div class="container">		
					<div class="logo">
						<h1><a href="index.html">MotoRide</a></h1>
					</div> 
                
					<div class="menu">
						<a href="" id="menuToggle"> <span class="navClosed"></span> </a>
						<nav>  
							<a href="#home" class="active scroll">Home</a> 
							<a href="#about" class="scroll">About</a>  
							<a href="#services" class="scroll">Services</a>  
							<a href="#news" class="scroll">News</a>
							<a href="#spec" class="scroll">Specifications</a> 
							<a href="#gallery" class="scroll">Gallery</a> 
							<a href="#contact" class="scroll">Contact</a> 
						</nav>
                        
						<script>
						(function($){
							// Menu Functions
							$(document).ready(function(){
							$('#menuToggle').click(function(e){
								var $parent = $(this).parent('.menu');
							  $parent.toggleClass("open");
							  var navState = $parent.hasClass('open') ? "hide" : "show";
							  $(this).attr("title", navState + " navigation");
									// Set the timeout to the animation length in the CSS.
									setTimeout(function(){
										console.log("timeout set");
										$('#menuToggle > span').toggleClass("navClosed").toggleClass("navOpen");
									}, 200);
								e.preventDefault();
							});
						  });
						})(jQuery);
						</script>
		 
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<!-- //header -->
			<div class="banner-text">
				<div class="container">		
					<h3>WE OFFER THE BEST <span>MOTORBIKES FOR RENT</span></h3>
					<a href="#about" class="buy btn-wayra scroll"> More About</a>
				</div> 
			</div>
		</div>
	</div>
	<!-- //banner -->
	<!-- welcome -->	
	<div id="about" class="welcome">
		<div class="container"> 
			<div class="welcome-agileinfo">
				<div class="col-md-6 w3ls_welcome_left"> 
					<div class="w3ls_welcome_right1">
						<h3 class="agileits-title"><span>A</span>bout Us</h3>
						<h6>RENT,<span> RIDE,</span>& RETURN !JUST Rs 3/KM: </h6>
						<p>So… You need to go somewhere. Maybe alone, maybe with a friend. You really don’t want to sit around, wait for a cab to arrive or sit behind someone else driving you. You want to move on your own. And then you think…What if I had a bike now? Someone hands you one, lets you take it where you want to go. Now you don’t really mind paying a little for that thoughtful gesture. Infact, you’re thankful. What a solid friend to have – someone who just gets you. Welcome to MOtoRide – we’re the friend who gets you! 🙂</p>
					</div> 
				</div>
				<div class="col-md-6 w3ls_welcome_right">  	
					<div class="agileits_w3layouts_welcome_grid">
						<img src="images/img1.jpg" alt=" " class="img-responsive" />
					</div> 
				</div> 
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //welcome -->	
	<!-- slid -->
	<div class="slid jarallax">
		<div class="slid-text">
			<h4>24/7 Customer Service Support</h4>
			<p>The MotoRide bike rental startups in Mangalore has brought an excellent opportunity for all the bike enthusiasts to travel across the country comfortably, conveniently and affordably. Now people can explore a new city on a rented bike of their choice, which allows them to enjoy a joyful ride experience without worrying about the bike maintenance hassles</p>
		</div>
		<div class="clearfix"> </div>
	</div>
	<!-- //slid -->
	<!-- services -->
	<div id="services" class="services">
		<div class="container"> 
			<h3 class="agileits-title w3title2"><span>S</span>ervices</h3>
			<div class="services-row-agileinfo">
				<div class="col-sm-4 col-xs-6 services-w3grid">
					<span class="fa fa-heart hi-icon" aria-hidden="true"></span>
					<h5>User Friendly</h5>
					<p>Easy access to the Services through best user Interface </p>
				</div>
				<div class="col-sm-4 col-xs-6 services-w3grid">
					<span class="fa fa-wrench hi-icon" aria-hidden="true"></span>
					<h5>Services</h5>
					<p>On the spot services and Spares,within the city limits</p>
				</div>
				<div class="col-sm-4 col-xs-6 services-w3grid">
					<span class="fa fa-bell hi-icon" aria-hidden="true"></span>
					<h5>Notifications</h5>
					<p>Timely remainders and messages about the ride schedule and fare </p>
				</div> 
				<div class="col-sm-4 col-xs-6 services-w3grid">
					<span class="fa fa-motorcycle hi-icon" aria-hidden="true"></span>
					<h5>Efficiency</h5>
					<p>Well maintained and equiped vehicles with regular checks </p>
				</div>
				<div class="col-sm-4 col-xs-6 services-w3grid">
					<span class="fa fa-check-square-o hi-icon" aria-hidden="true"></span>
					<h5>Assistence</h5>
					<p>24/7 assistence and home Services are available</p>
				</div>
				<div class="col-sm-4 col-xs-6 services-w3grid">
					<span class="fa fa-gears hi-icon" aria-hidden="true"></span>
					<h5>Help</h5>
					<p>Experienced machanics and staff for help and Customer support</p>
				</div> 
				<div class="clearfix"> </div>
			</div> 
		 </div>
	</div>
	<!-- //services -->
	<!-- specifications -->
	<div id="spec" class="spec jarallax">
		<div class="container"> 
			<h3 class="agileits-title w3title2"><span>S</span>pecifications</h3>
			<div class="specw3-agileits">
				<div class="col-md-6 spec-grids">	
					<h4>1. Gareless Scooters</h4>
					<ul>
						<li>
							<div class="specf-left">
								<p>Availability</p>
							</div>
							<div class="specf-right">
								<p>80</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Max Distance</p>
							</div>
							<div class="specf-right">
								<p>200 km</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Fuel economy</p>
							</div>
							<div class="specf-right">
								<p>50kmpl </p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Tank Capacity</p>
							</div>
							<div class="specf-right">
								<p>20 lr</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Max Speed</p>
							</div>
							<div class="specf-right">
								<p>90 km/hr</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Gps Tracker</p>
							</div>
							<div class="specf-right">
								<p>Available </p>
							</div>
							<div class="clearfix"> </div>
						</li>
					</ul>
				</div>	
				<div class="col-md-6 spec-grids">	
					<h4>2. Bikes</h4>
					<ul>
						<li>
							<div class="specf-left">
								<p>Availability</p>
							</div>
							<div class="specf-right">
								<p>100</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Max Distance</p>
							</div>
							<div class="specf-right">
								<p>1000 km</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Fuel economy</p>
							</div>
							<div class="specf-right">
								<p>30-80 kmpl</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Tank Capacity</p>
							</div>
							<div class="specf-right">
								<p>40-50 lr</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Max Speed</p>
							</div>
							<div class="specf-right">
								<p>90-160 kmph</p>
							</div>
							<div class="clearfix"> </div>
						</li>
						<li>
							<div class="specf-left">
								<p>Gps Tracker</p>
							</div>
							<div class="specf-right">
								<p>Available </p>
							</div>
							<div class="clearfix"> </div>
						</li>
					</ul>
				</div>	
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>			
	<!-- //specifications -->
	<!-- news -->
	<div id="news" class="news">   
		<div class="container"> 
			<h3 class="agileits-title w3title2"><span>N</span>ew Arrivals </h3>
			<div class="news-agileinfo">
				<div class="col-md-4 news-w3grid">
					<img src="images/img2.jpg" alt="">
					<div class="news-w3grid-info">
						<h5><span>10</span>December</h5>
						<h4>Harley Devidson</h4>
						<p>Especially for treckking and long diatance off ridding</p>
						<div class="article-links">
							<ul>
								<li><a href="#"><i class="glyphicon glyphicon-heart-empty"></i><span>1,052</span></a></li>
								<li><a href="#"><i class="glyphicon glyphicon-comment"></i><span>10K</span></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-4 news-w3grid">
					<img src="images/img3.jpg" alt="">
					<div class="news-w3grid-info">
						<h5><span>15</span>January</h5>
						<h4>KTM </h4>
						<p>To Satisify the Dreams of budding youngstars</p>
						<div class="article-links">
							<ul>
								<li><a href="#"><i class="glyphicon glyphicon-heart-empty"></i><span>1,052</span></a></li>
								<li><a href="#"><i class="glyphicon glyphicon-comment"></i><span>10K</span></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-4 news-w3grid">
					<img src="images/img4.jpg" alt="">
					<div class="news-w3grid-info">
						<h5><span>18</span>February </h5>
						<h4>Activa 6G</h4>
						<p>New Electric Scooter foe our 'Sisters' </p>
						<div class="article-links">
							<ul>
								<li><a href="#"><i class="glyphicon glyphicon-heart-empty"></i><span>1,052</span></a></li>
								<li><a href="#"><i class="glyphicon glyphicon-comment"></i><span>10K</span></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div> 
		</div> 
	</div>
	<!-- //news --> 
	<!-- gallery -->
	<div class="gallery" id="gallery">	 
		<h3 class="agileits-title w3title2"><span>G</span>allery</h3>
		<div class="gallery-info">	
			<div class="col-sm-6 gallery-grids glry-grid1">
				<div class="gallery-grids-top">
					<a class="b-link-stripe b-animate-go" href="images/g3.jpg" data-lightbox="example-set" data-title=" ">
						<img src="images/g3.jpg" class="img-responsive" alt=""/>
						<div class="b-wrapper">
							<span class="b-animate b-from-left"> 
								<i class="fa fa-arrows-alt" aria-hidden="true"></i>
							</span>					
						</div>
					</a>
				</div>
				<div class="gallery-grids-top">
					<div class="col-sm-6 col-xs-6 bottom-grids">
						<a class="b-link-stripe b-animate-go" href="images/g4.jpg" data-lightbox="example-set" data-title=" ">
							<img src="images/g4.jpg" class="img-responsive" alt=""/>
							<div class="b-wrapper">
								<span class="b-animate b-from-left">
									<i class="fa fa-arrows-alt" aria-hidden="true"></i>
								</span>					
							</div>
						</a>
					</div>
					<div class="col-sm-6 col-xs-6 bottom-grids">
						<a class="b-link-stripe b-animate-go" href="images/g5.jpg" data-lightbox="example-set" data-title=" ">
							<img src="images/g5.jpg" class="img-responsive" alt=""/>
							<div class="b-wrapper">
								<span class="b-animate b-from-left">
									<i class="fa fa-arrows-alt" aria-hidden="true"></i>
								</span>					
							</div>
						</a>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="col-sm-3 col-xs-6 gallery-grids glry-grid2">
				<a class="b-link-stripe b-animate-go" href="images/g2.jpg" data-lightbox="example-set" data-title=" ">
					<img src="images/g2.jpg" class="img-responsive" alt=""/>
					<div class="b-wrapper">
						<span class="b-animate b-from-left">
							<i class="fa fa-arrows-alt" aria-hidden="true"></i>
						</span>					
					</div>
				</a>
			</div>
			<div class="col-sm-3 col-xs-6 gallery-grids glry-grid3">
				<a class="b-link-stripe b-animate-go" href="images/g1.jpg" data-lightbox="example-set" data-title=" ">
					<img src="images/g1.jpg" class="img-responsive" alt=""/>
					<div class="b-wrapper">
						<span class="b-animate b-from-left">
							<i class="fa fa-arrows-alt" aria-hidden="true"></i>
						</span>					
					</div>
				</a>
				<a class="b-link-stripe b-animate-go" href="images/g6.jpg" data-lightbox="example-set" data-title=" ">
					<img src="images/g6.jpg" class="img-responsive" alt=""/>
					<div class="b-wrapper">
						<span class="b-animate b-from-left">
							<i class="fa fa-arrows-alt" aria-hidden="true"></i>
						</span>					
					</div>
				</a>
			</div>
			<div class="clearfix"></div>
			<script src="js/lightbox-plus-jquery.min.js"> </script>
		</div>
	</div>
	<!-- //gallery -->
	<!-- contact -->
	<div class="contact" id="contact">
		<div class="container"> 
			<h3 class="agileits-title w3title2"><span>B</span>ook Your Ride</h3>
			<div class="contact-grids">
				<div class="col-md-5 address">
					<h4>Get in touch with us</h4>
					<p class="cnt-p">MotoRide,Sky Hightes Near PVP Circle,Mangalore-3  </p>
					<div class="agile_social_icons">
						<ul class="agileits_social_list">
							<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
							<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
						</ul>
					</div>  
					<p>Dakshina Kannada </p>
					<p>Telephone : +91 9632400765</p>
					<p>FAX : +1 0824 42426</p>
					<p>Email : <a href="#">pvpejathaya@gmail.com</a></p>
				</div>
				<div class="col-md-7 contact-form">
					<form action="" method="post">
						<input type="text" name="name" placeholder="Name" required />
						<input type="email" class="email" name="email" placeholder="Email" required>
						<textarea placeholder="Address" name="address" required></textarea>
						<input type="submit" name="submit" value="SUBMIT">
					</form>
				</div>
				<div class="clearfix"> </div>	
			</div>
			<div class="w3-agilemap">  
				<iframe src="https://www.google.com/maps/d/embed?mid=1yfkYKAX1d8xi8-k2MeHyWPpELBk" width="640" height="480"></iframe><!--mapp-->
			</div> 
		</div>
	</div>

    
	<!-- //contact --> 
	<!-- footer -->
	<div class="footer">
		<div class="container"> 
			<div class="footer-w3lsrow">
				<div class="col-md-4 footer-grids footer-address">
					<h3>Contact Us :</h3>
					<ul>
						<li><i class="glyphicon glyphicon-send"></i>Manish,Vighnesh <span> CSE Departmant,AIET Mijar </span></li>
						<li><i class="glyphicon glyphicon-phone"></i> +91 8073046797 <span> +0825 1212 333 </span></li>
						<li><i class="glyphicon glyphicon-envelope"></i> <a href="#"> mjshriyan@gmail.com</a></li>
					</ul>
				</div>
				<div class="col-md-4 footer-grids subscribe">
					<h3>Newsletter :</h3> 
					<form action="" method="post">
						<input type="email" name="mail" placeholder="Your Email" required="">
						<input type="submit" name="Submit" value="Subscribe" >
						<div class="clearfix"> </div> 
					</form>
					
				</div>
				<div class="col-md-4 footer-grids footer-icons">
					<h3>Follow Us :</h3>
					<div class="agile_social_icons">
						<ul class="agileits_social_list">
							<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
							<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
						</ul>
					</div>  
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="footer-bottom">
				<p>© 2019 MotoRide. All rights reserved | Design by <a href="http://w3layouts.com">PVMJ</a></p>
			</div>
		</div>
	</div>
	<!-- //footer -->	  
	<!-- jarallax -->  
	<script src="js/SmoothScroll.min.js"></script> 
	<script src="js/jarallax.js"></script> 
	<script type="text/javascript">
		/* init Jarallax */
		$('.jarallax').jarallax({
			speed: 0.5,
			imgWidth: 1366,
			imgHeight: 768
		})
	</script>  
	<!-- //jarallax -->   
	<!-- start-smooth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>	
	<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
			
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
	</script>
	<!-- //end-smooth-scrolling -->	
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->  
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>
</html>