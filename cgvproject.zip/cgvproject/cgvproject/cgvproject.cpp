#include "stdafx.h"
#include<windows.h>	
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<GL/glut.h>
GLfloat colors[3][3]={{1.0,0.0,0.0},{0.0,1.0,0.0},{1.0,1.0,0.0}};

GLfloat colors1[5][5]={{0.0,0.6,0.6},{1.0,0.0,1.0},{1.0,0.6,0.0},{0.0,0.0,1.0},{1.0,1.0,1.0}};
static int pos1,pos;

int spear_color,particle_color,mainmenu;

#define drand() ((float)rand()/RAND_MAX)
#define PS_GRAVITY -9.8
#define PS_WATERFALL 0
#define PS_FOUNTAIN 1

typedef struct
{

    float x,y,z;
    float radius;
}PSsphere;

typedef struct

{
    float position[3];
    float previous[3];
    float velocity[3];
    float dampening;
    int alive;
} PSparticle;

PSparticle* particles=NULL;
#define NUM_SPHERES 1
PSsphere spheres[NUM_SPHERES]={{-0.1,0.6,0,0.4}};
int num_particles=20000;
int type = PS_WATERFALL;
int points = 1;
int draw_spheres = 1;
;
float flow = 1000;
float slow_down = -1;
float spin_x = 0;
float spin_y = 0;
int point_size = 5;


#include<sys/timeb.h>
#define CLK_TCK 1000
float timedelta(void)
{

    static long begin = 0;
    static long finish, difference;

    static struct timeb tb;
    ftime(&tb);
    finish = tb.time*1000+tb.millitm;

    difference = finish - begin;
    begin=finish;

    return (float)difference / (float) CLK_TCK;
}

void psTimeStep(PSparticle* p,float dt)
{
    if(p->alive == 0)
        return;
    p->velocity[0] += 0;
    p->velocity[1] += PS_GRAVITY*dt;
    p->velocity[2] += 0;

    p->previous[0] += p->position[0];
    p->previous[1] += p->position[1];
    p->previous[2] += p->position[2];


    p->position[0] += p->velocity[0]*dt;
    p->position[1] += p->velocity[1]*dt;
    p->position[2] += p->velocity[2]*dt;

}
void psnewparticle(PSparticle* p,float dt)
{

    if(type == PS_WATERFALL)
    {

        p->velocity[0] = -2*(drand()-0.2);
        p->velocity[1] = 0;
        p->velocity[2] = 2*(drand()-0.2);

        p->position[0]=0;
        p->position[1]=2.0;
        p->position[2]=0;

        p->previous[0]=p->position[0];
        p->previous[1]=p->position[1];
        p->previous[2]=p->position[2];

        p->dampening = 0.45*drand();
        p->alive =1;
    }

    else if (type == PS_FOUNTAIN)
    {
        p->velocity[0]=2*(drand()+0.5);
        p->velocity[1]=5;
        p->velocity[2]=2*(drand()-0.5);

        p->position[0]=-0.1;
        p->position[1]=0.8;
        p->position[2]=0;

        p->previous[0]=p->position[0];
        p->previous[1]=p->position[1];
         p->previous[2]=p->position[2];

         p->dampening=0.60 *drand();
         p->alive =1;
    }

    psTimeStep(p,2*dt*drand());
}

void reshape(int width,int height)
{
    float black[]={0,0,0,0};
    glViewport(0,0,width,height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60,(float)width/height,0.1,1000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0,1,3,0,1,0,0,1,0);
    glFogfv(GL_FOG_COLOR,black);
    glFogf(GL_FOG_START,2.5);
    glFogf(GL_FOG_END,4);
    glEnable(GL_FOG);
    glFogi(GL_FOG_MODE,GL_LINEAR);
    glPointSize(point_size);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHT0);

    timedelta();
}

void display(void)
{
    static int i;
    static float c;
    static int j=0;
    static char s[32];
    static int frames = 0;

     glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
     glPushMatrix();

     glRotatef(spin_y,1,0,0);
     glRotatef(spin_x,0,1,0);

     glEnable(GL_LIGHTING);
     if(draw_spheres)
     {

         for(i=0;i<draw_spheres;i++)

         {
             glPushMatrix();
             glTranslatef(spheres[i].x,spheres[i].y,spheres[i].z);
             glColor3fv(colors[pos1]);
             glutSolidSphere(spheres[i].radius,30,50);
             glPopMatrix();
         }
     }
     glDisable(GL_LIGHTING);

     glBegin(GL_QUADS);
     glColor3ub(0,128,255);

     glVertex3f(-2,0,-2);
     glVertex3f(-2,0,2);
     glVertex3f(2,0,2);
     glVertex3f(2,0,-2);
     glEnd();

     if(points)
     {

         glBegin(GL_POINTS);

         for( i=0;i<num_particles ;i++)
         {

             if(particles[i].alive==0)
                continue;
             c=particles[i].position[1]/2.1*255;

              glColor3fv(colors1[pos]);
              glVertex3fv(particles[i].position);
        }
        glEnd();
    }

glPopMatrix();
glutSwapBuffers();
}

void idle(void)
{

    static int i,j;
    static int living=0;
    static float dt;
    static float last =0;

    dt =timedelta();
    #if 1
    if (dt>0.1)
    {
        slow_down=1.0/(100*dt);
    }
    else if(dt < 0.1)
    {

        slow_down=1;
    }
    #endif
    dt *= slow_down;

     for( i=0;i<flow*dt ; i++)
     {
         psnewparticle(&particles[living],dt);
         living++;
         if(living >= num_particles)
            living=0;
    }
    for(i=0;i<num_particles;i++)
    {

        psTimeStep(&particles[i],dt);
    }
    glutPostRedisplay();
}
void visible(int state)
{
    if(state  == GLUT_VISIBLE)
        glutIdleFunc(idle);
    else
        glutIdleFunc(NULL);
}
void keyboard(unsigned char key,int x,int y)
{

    static int fullscreen=0;
    static int old_x=50;
    static int old_y=50;
    static int old_width=512;
    static int old_height=512;
    static int s=0;

    switch(key)
    {



        case 27:break;

        case 't':if(type == PS_WATERFALL)
        type = PS_FOUNTAIN;
        else if (type == PS_FOUNTAIN)
            type = PS_WATERFALL;
        break;

        case '+' :flow+=100;
             if(flow>num_particles)
                flow=num_particles;
                printf("%g particles/second\n",flow);
                break;

         case '-' : flow -=100;
               if(flow<0)
                    flow=0;
               printf("%g particles/second\n",flow);
               break;

         case 'p' : point_size++;
           glPointSize(point_size);
           break;

        case 'P': point_size--;
            if(point_size < 1)
                point_size=1;
            glPointSize(point_size);
            break;

        case '4': pos1=rand()%3 ;
        spheres[s].x -=0.05;
        break;

        case '6' :
            spheres[s].x +=0.05;
    pos1=rand()%3 ;
    break;

    case '2' :pos1=rand()%3 ;
    spheres[s].y -=0.05;
    break;

    case '8':pos1=rand()%3 ;
    spheres[s].y +=0.05;
    break;

    case '7' :pos1=rand()%3 ;
           spheres[s].z -=0.05;
           break;

   case '3' :pos1=rand()%3 ;
   spheres[s].z +=0.05;
   break;

   case '9' : spheres[s].radius +=0.05;
   break;


   case '1' : spheres[s].radius -=0.05;
   break;
}
}
void menu(int item)
{
    keyboard((unsigned char)item,0, 0);
}

void menustate(int state)
{
    if(state == GLUT_MENU_IN_USE)
        timedelta();
}

int old_x,old_y;

void mouse(int button,int state,int x,int y)
{

    old_x=x;
    old_y=y;
    glutPostRedisplay();
}

void motion (int x, int y)
{
   spin_x= x-old_x;
    spin_y=old_y;

    glutPostRedisplay();
}

void spear_change_color(int id)
{

    switch(id)
    {
       case 1:pos1=1;
       break;
       case 2:pos1=0;
       break;
       case 3:pos1=2;
         break;

    }
}


void particle_change_color(int id)
{
    switch(id)
    {

        case 0:pos=1;
	        break;	
        case 1:pos=2;
        break;
        case 2:pos=3;
        break;
        case 3:pos=4;
        break;
    }
}
int main(int argc,char** argv)
{
    glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
    glutInitWindowPosition(0,0);
    glutInitWindowSize(640,480);
    glutInit(&argc,argv);
    glutCreateWindow("CG mini project");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMotionFunc(motion);
    glutMouseFunc(mouse);
    glutKeyboardFunc(keyboard);


    glutMenuStateFunc(menustate);
    spear_color = glutCreateMenu(spear_change_color);
    glutAddMenuEntry("Green",1);
    glutAddMenuEntry("red",2);
    glutAddMenuEntry("yellow",3);
    particle_color = glutCreateMenu(particle_change_color);
    glutAddMenuEntry("Magenta",0);
    glutAddMenuEntry("Orange",1);
    glutAddMenuEntry("Blue",2);
    glutAddMenuEntry("White",3);
    mainmenu=glutCreateMenu(menu);
    glutAddMenuEntry("particle",0);
    glutAddMenuEntry("[t] spray type",'t');
    glutAddMenuEntry("[-] less flow",'-');
    glutAddMenuEntry("[+] More flow",'+');
    glutAddMenuEntry("[p] smaller points ",'p');
    glutAddMenuEntry("[p] Larger points",'p');
    glutAddMenuEntry("",0);
    glutAddMenuEntry("Use the numeric keypad to move the spheres",0);
    glutAddSubMenu("spear",spear_color);
    glutAddSubMenu("particles...",particle_color);
    glutAddMenuEntry("",0);
    glutAttachMenu(GLUT_RIGHT_BUTTON);

    particles = (PSparticle*)malloc(sizeof(PSparticle) *num_particles);
    glutVisibilityFunc(visible);
    glutMainLoop();
    return 0;

}


