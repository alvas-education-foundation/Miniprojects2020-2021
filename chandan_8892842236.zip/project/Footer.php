<!DOCTYPE html >
<head>
<title>Untitled Document</title>
<link rel = "stylesheet" type = "text/css" href = "mystyle.css">
<link rel = "stylesheet" type = "text/css" href = "menu.css">
</head>
<body >
<table width="1340" bgcolor="#999898" style=" color:white; bottom:0px; font-size:20px;">
  <tr>
    <td class = "f" align="center">Copyright&copy;2019 </td>
  </tr>
</table>
</body>
</html>
