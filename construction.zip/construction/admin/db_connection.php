<?php  
 
$dbcon=mysqli_connect("localhost","root","edwin");  
mysqli_select_db($dbcon,"users");  
?>  