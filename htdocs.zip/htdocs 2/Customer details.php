<html>
<head>
<link rel="stylesheet" type="text/css" href="style2.css" >
</head>
<body background="adm.jpg">
<div>
<center>
<div id="main-wrapper">
<?php
$servername = "localhost";
$dbname = "restaurant";

// Create connection
$conn = new mysqli($servername, "root", "root", $dbname);
// Check connection
if ($conn->connect_error) {
echo "<script>alert('Invalid credentials');</script>";
} 
$sql = "SELECT * FROM customer ;";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<table><tr><th>Address </th><th>Customer name </th><th> Customer Password</th><th>Phone Number </th><th>User Name</th></tr> ";
     
    while($row = $result->fetch_assoc()) {
     echo "<tr><td>".$row["address"]."</td><td>".$row["cust_name"]."</td><td>".$row["cust_pwd"]."</td><td>".$row["phno"]."</td><td>".$row["uname"]."&nbsp</td></tr>" ;
    }
   echo "</table>";
}

 else {
    echo "0 results";
}
?>
<br><br>
<center><a href="apk.php"><background color="blue" size="1"><button>BACK</button></font></a>
<br><br>
<center><a href="rest.php"><background color="yellow" size="1"><button>HOME</button></font></a>
</div>
</div>
</body>


</html>