<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" >
</head>
<body background="">
<div id="main-wrapper"> 
 <div id="Itemslist" align="center">
      <a href="Veglists.php"><font color="white" size="5"><button>VEG</button></font></a><br><br>
      <a href="nonveglist.php"><font color="white" size="5"><button>NON VEG</button></font></a><br><br>
      <a href="colddrinks.php"><font color="white" size="5"><button>COLD DRINKS</button></font></a><br><br>
      <a href="icecream.php"><font color="white" size="5"><button>ICE CREAMS</button></font></a><br><br>
      </div>
      </div>

</body>
<br><br>
<center><a href="rest.php"><background color="yellow" size="5"><button>HOME</button></font></a>
</html>