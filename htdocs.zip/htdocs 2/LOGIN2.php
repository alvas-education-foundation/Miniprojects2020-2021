<html>
<head>
<link rel="stylesheet" type="text/css" href="style1.css" >
</head>
<body>
<div id="main-wrapper">
		
                
<form action="apk.php" method="post">
		<center><font color="white" size="5">LOGIN</font></center>
		<center><input class="inputvalues" type="text" placeholder="User name" name="name" required/><br><br>
		<input class="inputvalues" type="password" placeholder="Password" name="pwdd" required/><br><br>
		<input type="submit" id="submit_btn" name="login" value="LOGIN"><br><br>
                </form>
               <center> <font color="yellow"><b>Don't Have an Account?</b></font> </center>
             <center><button onclick="document.getElementById('id01').style.display='block'">Sign Up</button>
                <div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
  <form class="modal-content animate" action="rest.php">
    <div class="container">
      <label><b>Email/USERNAME</b></label>
      <input type="text" placeholder="Enter Email or User Name" name="email" required>
      <label><b>Mobile Number</b></label>
      <input type="text" placeholder="Enter Mobile Number" name="mob" required>
      <label><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>

      <label><b>Repeat Password</b></label>
      <input type="password" placeholder="Repeat Password" name="psw-repeat" required>
      <input type="checkbox" checked="checked"> Remember me
      <div class="clearfix">
        <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
        <button type="submit" class="signupbtn">Sign Up</button>
         
      </div>
</div>
</body>
</html>