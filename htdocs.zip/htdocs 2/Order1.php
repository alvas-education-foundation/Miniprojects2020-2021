
<html>
<head>
<title>Your Order Details</title>
<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<form>
<center><div id="main_wrapper">
<?php
$servername = "localhost";
$dbname = "restaurant";
// Create connection
$conn =mysqli_connect($servername, "root", "root", $dbname);

if($_SERVER['REQUEST_METHOD'] == "POST")
{
	//$order_no = mysqli_real_escape_string($conn, $_POST['order_no']);
	$item_name = mysqli_real_escape_string($conn, $_POST['item_name']);	
	$order_price = mysqli_real_escape_string($conn, $_POST['order_price']);
  	$cust_name= mysqli_real_escape_string($conn, $_POST['cust_name']);
	$quantity = mysqli_real_escape_string($conn, $_POST['quantity']); 
 	$query1="INSERT INTO orders VALUES('','$item_name','$order_price','$cust_name','$quantity')";
 	$result = mysqli_query($conn, $query1);
 	echo '<span style="color:green;text-align:center;"> order Successfully</span>';
    // header("Location: rentno.php");
}
$sql = "SELECT * FROM orders WHERE cust_name = '$cust_name'";
$result = mysqli_query($conn, $sql);
 $res = mysqli_num_rows($result);
if ($res > 0) {
    echo "<table><tr><th>Oder No </th><th>Item name  </th><th>Order Price</th><th>Customer Name</th><th>Quantity</th></tr>";
     
    while($row = $result->fetch_assoc()) {
     echo "<tr><td>".$row["order_no"]."</td><td>".$row["item_name"]."</td><td>".$row["order_price"]."</td><td>".$row["cust_name"]."</td><td>
     ".$row["quantity"]."&nbsp</td</tr>";

    }
   echo "</table>";
}

 else {
    echo "0 results";
}?>
<a href="Itemslist.php" align="left"> <input type="button" id="submit_btn" value="back"></a>
		</form>
</div></center>	<br><br><br>
</body>
</html>