<html>
<head>

        <link rel="stylesheet" type="text/css" href="style2.css" >
</head>
<body   background="adm.jpg">
<center>
 <div id="main-wrapper">
<form action="admin.php" method="post">
		<center><font color="black" size="5">LOGIN</font></center>
		<center>
			<input class="inputvalues" type="text" placeholder="User name" name="name" required/><br><br>
			<input class="inputvalues" type="password" placeholder="Password" name="pwdd" required/><br><br>
			<input type="submit" id="submit_btn" name="login" value="LOGIN"><br><br>


        </center>
        </form>
<a href="rest.php"><background color="yellow" size="5"><button>HOME</button></font></a>
        </div>

</center>

        <?php
  $servername = "localhost";
  $dbname = "restaurant";

  $con = new mysqli($servername, "root", "root", $dbname);  
  if(isset($_POST['login']))
  {
    $name=$_POST['name'];
    $pwdd=$_POST['pwdd'];

	$query="select * from admin WHERE adminname='$name' AND adminpwd='$pwdd'";
      $query_run=mysqli_query($con,$query);
      if(mysqli_num_rows($query_run)>0)
      {
        header('location:apk.php');
      }
      else
      {
        echo '<script type="text/javascript"> alert("Invalid Credentials")</script>';
      }
      
  }
  
?>

  
 </body>
</html>