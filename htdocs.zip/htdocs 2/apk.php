<html>
<head>
  <link rel="stylesheet" type="text/css" href="style2.css" >
</head>
<center>
<body background="adm.jpg">
<left><font size="20" color="black">Welcome Administrator</font><br></left>

<div>
<div id="main-wrapper">
<a href="order.php"><font color="black" size="10"><button>ORDERS</button></font></a><br><br>
<a href="Customer details.php"><font color="black" size="10"><button>CUSTOMER DETAILS</button></font></a><br><br>

<a href="admin.php"><font color="black" size="10"><button>LOG OUT</button></font></a><br><br>

</div>
</div>

</body>
</center>
</html>