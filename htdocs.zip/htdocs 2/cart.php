<?php
session_start ();
require 'connect.php';
require 'item.php';
if (isset ( $_GET ['order_no']  ) )
{
	$result = mysqli_query ( $con, 'select * from orders where order_no=' . $GET ['order_no']);
	$orders = mysqli_fetch_object ($result);
	$item= new Item();
	$item->order_no= $product->order_no;
	$item->item_name= $product->item_name;
	$item->order_price= $product->order_price;
	$item->quantity=1;
	$index=-1;
	if (isset  ($_SESSION ['cart'] )) 
	{
		$cart = unserialize (serialize($_SESSION ['cart']));
		for($i=0;$i< count ($cart); $i++)
			if($cart [$i]->order_no==$_GET ['order_no']){
			$index=$i;
			break;
			}
	} 
	if($index==-1)
		$_SESSION ['cart'] []=$item;
	else {
		$cart [$index]->quantity++;
		$_SESSION ['cart']=$cart;

	}
}


if (isset ( $_GET ['index'])){
	$cart = unserialize (serialize($_SESSION ['cart']));
	unset ($cart  [$_GET ['index']]);
	$cart= array_values ($cart);
}
?>
<table cellpadding="2" cellpadding="2" border="0">
	<tr>
		<th>Order Number</th>
		<th>Item Name</th>
		<th>Order price</th>
		<th>Customer Name</th>
		<th>Quantity <img src="images/save.png"></th>
		<th>Total</th>
	</tr>
	$cart = unserialize (serialize($_SESSION ['cart']));
	$s=0;
	$index=0;
	for($i=0;$i< count ($cart); $i++) {
	$s += $cart [$si]->order_price * $cart [$i]->quantity;
	?>
	<tr> 
		<td>a href="cart.php?index=<?php echo $index; ?>"
		onclick="return confirm('Are You Sure?')">Delete</a></td>
		<td><?php echo $cart[$i]->order_no; ?> </td>
		<td><?php echo $cart[$i]->item_name; ?> </td>
		<td><?php echo $cart[$i]->order_price; ?> </td>
		<td><?php echo $cart[$i]->cust_name; ?> </td>
		<td><input type="text" value"<?php echo $cart[$i]->quantity; ?>"> style="width: 30px;" name="quantity[]"></td>
		<td><?php echo $cart[$i]->order_price* $cart[$i]->quantity; ?> </td>
	</tr>
	 $index ++;
	 }
	 ?>
	 <tr>
	 	<td> colspan="5" align="right">Sum</td>
	 	<td> align="left"><?php echo $s; ?></td>
	 </tr>
</table>
<br>
<a href="index.php">Continue Order</a>
