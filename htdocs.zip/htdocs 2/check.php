<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Untitled Document</title>
 </head>

 <body>
 <body background="blue">
 <form action="check.php" method="post">
 Name: <input name="Name" type="text" id="Name" /><br />
<br />
  <br />
   Which you do you want to likes?<br />
         <input type="checkbox" name="Hobbies[]" value="Books" />Books<br />
    <input type="checkbox" name="Hobbies[]" value="Movies" />Movies<br />
   <input type="checkbox" name="Hobbies[]" value="Sports" />Sports<br />
  <input type="checkbox" name="Hobbies[]" value="Games" />Games<br />
  <input type="checkbox" name="Hobbies[]" value="Travelling" />Travelling<br />  

  worked: <input name="Worked" type="text" id="Worked" /><br />
   <br />

<input type="submit" name="submit" value="Submit" />
<input type="reset" name="reset" value="reset" />

 </form>
  </body>
 </html>

