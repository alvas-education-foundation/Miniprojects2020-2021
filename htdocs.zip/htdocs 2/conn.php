<html>
<?php
$conn = new mysqli($servername, "ankith", "123", $dbname);
// Check connection
if ($conn->connect_error) {
echo "<script>alert('Invalid credentials');</script>";
} 
$sql = "SELECT * FROM orders ;";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
{
header(location: "cart.php");
}
?>
<br><br>
<center><a href="rest.php"><background color="yellow" size="5"><button>HOME</button></font></a>
</html>