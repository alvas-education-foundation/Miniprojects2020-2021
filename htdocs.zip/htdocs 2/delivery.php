<html>
<head>
<title>Your Order Details</title>
<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<form>
<center><div id="main_wrapper">
<?php
$servername = "localhost";
$dbname = "restaurant";
// Create connection
$conn =mysqli_connect($servername, "root", "root", $dbname);

if($_SERVER['REQUEST_METHOD'] == "POST")
{
  //$delivery_id = mysqli_real_escape_string($conn, $_POST['delivery_id']);
  $order_no = mysqli_real_escape_string($conn, $_POST['order_no']); 
  $cust_name = mysqli_real_escape_string($conn, $_POST['name']);
    $delivery_time= mysqli_real_escape_string($conn, $_POST['delivery_time']);
  $quantity = mysqli_real_escape_string($conn, $_POST['quantity']); 
  $query1="INSERT INTO delivery VALUES('','$order_no','$cust_name','$delivery_time','$quantity')";
  $result = mysqli_query($conn, $query1);
  echo '<span style="color:green;text-align:center;"> order Successfully</span>';
  
}
$sql = "SELECT * FROM orders WHERE cust_name = '$cust_name'";
$result = mysqli_query($conn, $sql);
 $res = mysqli_num_rows($result);
if ($res > 0) {
    echo "<table><tr><th>delievry id </th><th>Order no  </th><th>Customer Name</th><th>Delivery Time</th><th>Quantity</th></tr>";
     
    while($row = $result->fetch_assoc()) {
     echo "<tr><td>".$row["delivery_id"]."</td><td>".$row["order_no"]."</td><td>".$row["cust_name"]."</td><td>".$row["delivery_time"]."</td><td>
     ".$row["quantity"]."&nbsp</td</tr>";

    }
   echo "</table>";
}

 else {
    echo "0 results";
}?>
<a href="Order.html" align="left"> <input type="button" id="submit_btn" value="back"></a>
    </form>
</div></center> <br><br><br>
</body>
</html>