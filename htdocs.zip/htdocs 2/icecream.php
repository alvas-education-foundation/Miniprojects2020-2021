<html>
<head>
<link rel="stylesheet" type="text/css" href="style2.css" >
</head>
<body background="a5.jpg">
<div>
<center><div id="main-wrapper">
<?php
$servername = "localhost";
$dbname = "restaurant";

// Create connection
$conn = new mysqli($servername, "root", "root", $dbname);
// Check connection
if ($conn->connect_error) {
echo "<script>alert('Invalid credentials');</script>";
} 

$sql = "SELECT * FROM item where item_type='ice-cream';";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>Item name  </th><th>Item Price </th><th>Item type  </th><th>Quantity </th></tr>";
     
    while($row = $result->fetch_assoc()) {
     echo "<tr><td>".$row["item_name"]."</td><td>".$row["item_price"]."</td><td>".$row["item_type"]."&nbsp</td><td>".$row["quantity"]."</td><td></td></tr>";
  
    }
   echo "</table>";
}

 else {
    echo "0 results";
}
?>
</div><center>

<center>
<div id="main-wrapper" align="center">
    <form method="post" action="Order1.php" align="center">

      <font color="f9690e" size="7" style="Times New Roman"> </font><br><br>

      Item Name <input class="inputvalues" type="text" name="item_name" placeholder="Item name" required/><br><br>

      Order Price <input class="inputvalues" type="text" name="order_price" placeholder="order price" required/><br><br> 

      Customer Name <input class="inputvalues" type="text" name="cust_name" placeholder="customer name" required/><br><br> 

      Quantity<input class="inputvalues" type="text" name="quantity" placeholder="quantity" required/><br><br>

    <input type="submit" id="submit_btn" name="button"  value="submit" /><br><br>
   
</form>
 <a href="Itemslist.php"><background color="yellow" size="5"><button>CANCEL</button></font></a>
</div></center>
</body>
</html>
