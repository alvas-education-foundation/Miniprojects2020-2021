<html>
<head>
 <link rel="stylesheet" type="text/css" href="style1.css" >
</head>
<body>
<div id="main-wrapper">        
  <form class="modal-content animate" action="auth.php">
    <div class="container">
      <label><b>Username</b></label>
      <input type="text" placeholder="User Name" name="username" required>
      <label><b>Customer Name</b></label>
      <input type="text" placeholder="Customer Name" name="cname" required>
       <label><b>Mobile Number</b></label>
      <input type="text" placeholder="Enter Mobile Number" name="mob" required>
       <label><b>Address</b></label>
      <input type="text" placeholder="Address" name="add" required>
      <label><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>
      <label><b>Repeat Password</b></label>
      <input type="password" placeholder="Repeat Password" name="psw-repeat" required>
      <input type="checkbox" checked="checked"> Remember me
      <div class="clearfix">
        <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
        <button type="submit" class="signupbtn" name="submit_btn">Sign Up</button>
         
      </div>

          
    </div>
  </form>
  </div>
  <?php
$servername = "localhost";
$username = "ankith";
$password="123";
$dbname = "restuarant";


// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error)
{
echo "<script>alert('Invalid credentials');</script>";
} 
else if(isset($_POST['submit_btn']))
{
    $uname=$_POST['username'];
    $cname =$_POST['cname'];
    $pwd=$_POST['psw'];
    $rpwd=$_POST['psw-repeat'];
    $add=$_POST['add'];
    $phone=$_POST['mob'];
    if($pwd==$rpwd)
    {
      $sql = "insert into customer values('$uname','$cname','$pwd','$add','$phone');";
      $result = $conn->query($sql);
      header(location:"login3.php");
    }
    else
    {
      echo "<script>alert('Invalid credentials');</script>";
    }
  }


?>  
  </body>
  </html>