<html>
<head>
<title>Corp detailed Information</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="images.jfif"><br><br><br><br>
<div id="main-wrapper">
<center><font color="black">
<b>Enter Department ID to avail Operations Info</b></font><br><br><br><br>
<form action="so_info.php" method="post">
<input class="inputvalues" type="text" placeholder="Search current operations" name="name" required/><br><br><br>
	<input type="submit" id="submit_btn" name="submit_btn"><br><br>
	</form>
	</center>
	</div>
</body>
</form>
</body>
</html>
