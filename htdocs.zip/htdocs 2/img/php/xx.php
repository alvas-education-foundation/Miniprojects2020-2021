<html>
<body background="images.jfif">
<br><br>
<link rel="stylesheet" type="text/css" href="style1.css">
<form>
<center>
<a href="sold_info.php"> <input type="button" id="button" value="Soldier Information"></a>&nbsp&nbsp&nbsp&nbsp
<a href="allsoldetails.php"> <input type="button" id="button" value="All soldier details"></a>
<a href="sld.php"> <input type="button" id="button" value="Corp Details Entry"></a><br><br><br><br><br><br><br>
<a href="dept.php"> <input type="button" id="button" value="Department"></a><br><br><br><br><br><br><br>
<a href="weap_query.php"> <input type="button" id="button" value="Weapon Details"></a><br><br><br><br><br><br><br>
<a href="so.php"> <input type="button" id="button" value="Sting Operations"></a><br><br><br><br><br><br><br>
<a href="dlocation.php"> <input type="button" id="button" value="Department Location"></a><br><br><br><br><br><br><br><br>
<!--<a href="soldier.php"> <input type="button" id="button" value="soldier info"></a><br><br><br><br><br><br><br><br>-->



</form>

</body>
</html>