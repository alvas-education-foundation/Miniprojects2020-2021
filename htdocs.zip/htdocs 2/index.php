<?php
require 'connect.php';
$result = mysqli_query($con, 'select * from orders');
?>

<table cellpadding="2" cellpadding="2" border="0">
	<tr>
		<th>Order Number</th>
		<th>Item Name</th>
		<th>Order price</th>
		<th>Customer Name</th>
	</tr>
	<?php> while($order=mysqli_fetch_object($result)) { ?>
		<tr>
			<td><?php echo $product->order_no; ?></td>
			<td><?php echo $product->item_name; ?></td>
			<td><?php echo $product->order_price; ?></td>
			<td><?php echo $product->cust_name; ?></td>
		</tr>
	} 
?>
</table>

			
		    
