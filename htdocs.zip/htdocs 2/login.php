<?php
$servername = "localhost";
$username = "name";
$password = "email";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
    alert("Username or password is incorrect");
}
else
{
echo "Connected successfully";
}
?>