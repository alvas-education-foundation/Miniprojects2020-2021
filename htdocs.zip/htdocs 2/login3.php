<html>
<head>
 <link rel="stylesheet" type="text/css" href="style3.css" >
</head>
<body >

<div id="main-wrapper">        
	<form action="login3c.php" method="post">
		
		   <center><font color="white" size="5">LOGIN</font></center>
		   <center><input class="inputvalues" type="text" placeholder="User name" name="name" required/><br><br>
		   <input class="inputvalues" type="password" placeholder="Password" name="pwdd" required/><br><br>
		   <input type="submit" id="submit_btn" name="login" value="LOGIN"><br><br>
               
	</form>
<br><br>

        </div>
<br><br>
<center>
<div id="main-wrapper">  
    <font color="yellow"><b>Don't Have an Account?</b></font> <br>
    <a href="auth.php"><button >Sign Up</button></a>  
    <a href="rest.php"><background color="yellow" size="5"><button>HOME</button></font></a> <br>
  </center>
</div>

  </body>
  </html>