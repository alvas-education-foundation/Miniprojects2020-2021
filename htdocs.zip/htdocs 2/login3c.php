<?php
session_start();

  $servername = "localhost";
  $dbname = "restaurant";
  $con = new mysqli($servername, "root", "root", $dbname);
 
  if(isset($_POST['login']))
  {
    $name=$_POST['name'];
    $pwdd=$_POST['pwdd'];
    
    $_SESSION['name']=$_POST['name'];

    $query="select * from customer WHERE uname='$name' AND cust_pwd='$pwdd'";
      $query_run=mysqli_query($con,$query);
      if(mysqli_num_rows($query_run)>0)
      {
        header('location:menu.php');
      }
      else
      {
        echo '<script type="text/javascript"> alert("Invalid Credentials")</script>';
      }
  }

?>
