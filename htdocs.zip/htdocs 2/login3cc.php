<?php

session_start();

$servername = "localhost";
  $dbname = "restaurant";
  $con = new mysqli($servername, "root", "root", $dbname);
 
if(isset($_POST['orders']))
  {
    $name=$_SESSION['name'];
  
    $query="select * from orders WHERE cust_name = '$name'";
      $query_run=mysqli_query($con,$query);
      if(mysqli_num_rows($query_run)>0)
      {
          echo "<table><tr><th>Order no </th><th>Item name  </th><th>Order price</th><th>Customer name</th><th>Quantity</th></tr>";
     
    while($row = $result->fetch_assoc()) {
     echo "<tr><td>".$row["order_no"]."</td><td>".$row["item_name"]."</td><td>".$row["order_price"]."</td><td>".$row["cust_name"]."</td><td>
     ".$row["quantity"]."&nbsp</td</tr>";
      }
   echo "</table>";
}
      else
      {
        echo '<script type="text/javascript"> alert("Invalid Credentials")</script>';
      }
  }
?>