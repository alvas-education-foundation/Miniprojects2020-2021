<html>
<head>
   <link rel="stylesheet" type="text/css" href="style.css" >
   </head>
 <body background="a24.jpg">
<div id="main-wrapper"> 
 <div id="menu" align="center">


      <a href="Itemslist.php"><font color="white" size="5"><button>ITEMS MENU</button></font></a><br><br>
  </div>
  </div>
  <br><br><br><br>
  <div id="main-wrapper"> 
 <div id="menu" align="center">

  
   <a href="orderlogin.php"><font color="white" size="5"><button>ORDERS</button></font></a>

</div>
 </div>
 <br><br><br><br><br><br><br><br><br><br><br><br><br>
 <div id="menu" align="right">
   <a href="login3.php"><background color="yellow" size="5"><button>LOGOUT</button></font></a>

   </div>
<body>
</html>