<html>
<head>
<link rel="stylesheet" type="text/css" href="style2.css" >
</head>
<body background="adm.jpg">
<div>
<center>
<div id="main-wrapper">
<?php
$servername = "localhost";
$dbname = "restaurant";

// Create connection
$conn = new mysqli($servername, "root", "root", $dbname);
// Check connection
if ($conn->connect_error) {
echo "<script>alert('Invalid credentials');</script>";
} 
$sql = "SELECT * FROM orders ;";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<table><tr><th>Order number </th><th>Item name </th><th> Order price</th><th>Cust name </th><th>Quantity</th></tr> ";
     
    while($row = $result->fetch_assoc()) {
     echo "<tr><td>".$row["order_no"]."</td><td>".$row["item_name"]."</td><td>".$row["order_price"]."</td><td>".$row["cust_name"]."</td><td>".$row["quantity"]."&nbsp</td></tr>" ;
    }
   echo "</table>";
}

 else {
    echo "0 results";
}
?>

<br><br>
<center><a href="apk.php"><button size="10" bgcolor="red">BACK</button></a>
<br><br>

<center><a href="rest.php"><background color="yellow" size="5"><button>HOME</button></font></a>
</div>
</div>
</body>

</html>