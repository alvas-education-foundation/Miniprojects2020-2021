<html>
<head>
<link rel="stylesheet" type="text/css" href="style2.css" >
</head>
<body background="adm.jpg">
<div>
<center>
<div id="main-wrapper">

<?php
session_start();

$servername = "localhost";
$dbname = "restaurant";

// Create connection
$conn = new mysqli($servername, "root", "root", $dbname);
// Check connection
if ($conn->connect_error) {
echo "<script>alert('Invalid credentials');</script>";
} 
$sql = "SELECT * FROM orders WHERE cust_name='{$_SESSION['name']}';";
$result = $conn->query($sql);
if ($result->num_rows>0) {
    echo "<table><tr><th>Order number </th><th>Item name </th><th> Order price</th><th>Cust name </th><th>Quantity</th></tr> ";
     
    while($row = $result->fetch_assoc()) {
     echo "<tr><td>".$row["order_no"]."</td><td>".$row["item_name"]."</td><td>".$row["order_price"]."</td><td>".$row["cust_name"]."</td><td>".$row["quantity"]."&nbsp</td></tr>";
    }
   echo "</table>";
}

 else {
    echo "0 results";
}
?>

<br><br>
<center><a href="menu.php"><button size="10" bgcolor="red">BACK</button></a>
<br><br>
</div>
</div>
</body>

</html>