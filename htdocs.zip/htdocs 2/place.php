<html>
<head>
<link rel="stylesheet" type="text/css" href="style2.css" >
</head>
<body background="a22.jpg">
<div>
<center><div id="main-wrapper">

<?php
$servername = "localhost";
$dbname = "restaurant";
$servername = "localhost";
$username = "ankith";
$password="123";
$dbname = "restaurant";


// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);
// Check connection
if ($conn->connect_error)
{
echo "<script>alert('Invalid credentials');</script>";
} 
else if(isset($_POST['submit_btn']))
{
    $uname=$_POST['username'];
    $cname =$_POST['cname'];
    $pwd=$_POST['psw'];
    $rpwd=$_POST['psw-repeat'];
    $add=$_POST['add'];
    $phone=$_POST['mob'];
    if($pwd==$rpwd)
    {
      $sql = "insert into customer values('$uname','$cname','$pwd','$add','$phone');";
      $result = $conn->query($sql);
      /*header(location: "login3.php");*/
    }
    else
    {
      echo "<script>alert('Invalid credentials');</script>";
    }
  }
?>  
  </body>
  </html>