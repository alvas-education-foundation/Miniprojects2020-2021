<html>
<head>
<title>Your Order Details</title>
<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<form>
<center><div id="main_wrapper">

<?php

$servername = "localhost";
$dbname="popcorn";

// Create connection
$conn =mysqli_connect($servername, "root", "root", $dbname);

if($_SERVER['REQUEST_METHOD'] == "POST")
{
	$name = mysqli_real_escape_string($conn, $_POST['firstname']);
	$total = mysqli_real_escape_string($conn, $_POST['total']);
	$item1 = mysqli_real_escape_string($conn, $_POST['up']);
	$item2 = mysqli_real_escape_string($conn, $_POST['cp']);
	$item3 = mysqli_real_escape_string($conn, $_POST['cnp']);
	$item4 = mysqli_real_escape_string($conn, $_POST['tnp']);

	$query1="INSERT INTO `order` (`name`, `item1`, `item2`, `item3`, `item4`, `totalcost`) VALUES ('$name','$item1','$item2','$item3','$item4','$total')";

	$result = mysqli_query($conn, $query1);
	echo '<span style="color:green;text-align:center;"> order Successfully</span>';
}
$sql = "SELECT * FROM order WHERE name = '$name'";
$result = mysqli_query($conn, $sql);
 
if (1) {
    echo "<table><tr><th>Name </th><th>Unpoped Popcorn  </th><th>Caramel Popcorn  </th><th>Caramel Nut Popcorn  </th><th>Toffey Nut Popcorn  </th><th>Total</th></tr>";
     
     echo "<tr><td>$name</td><td>$item1</td><td>$item2</td><td>$item3</td><td>$item4</td><td>$total&nbsp</td</tr>";

   echo "</table>";
}

 else {
    echo "0 results";
}
?>
<a href="popcorn.html" align="left"> <input type="button" id="submit_btn" value="back"></a>
		</form>
</div></center>	<br><br><br>
</form>
</body>
</html>