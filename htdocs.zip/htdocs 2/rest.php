<html>
<head>
	<title>Welcome to Login Portal</title>
        <link rel="stylesheet" type="text/css" href="style.css" >
</head>
<body>
 <center><font color="white" size="20" style="bold"><B> RESTAURANT MANAGEMENT</B> </font></center><br><br><br><br>
 <div id="main-wrapper"> 
 <div id="menu" align="center">
      <a href="admin.php"><font color="white" size="5">ADMIN</font></a>
  </div>
  </div><tr><tr>
  <div id="main-wrapper"> 
  <div id="menu" align="center">
      <a href="login3.php"><font color="white" size="5">CUSTOMER LOGIN</font></a>
  </div>
 </div>
</body>
</html>
