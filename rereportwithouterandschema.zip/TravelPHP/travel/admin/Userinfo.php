<!DOCTYPE html>
<html>
<head>
    <title>Userinfo </title>
</head>
    
<body>
    <table>
        
        <tr>
        <th>Name&nbsp;&nbsp;</th>
        <th>Email</th>
        </tr>
       
    </table>
    
<?php
  $conn = mysqli_connect('localhost','root', '','tourism');
  $id=4;
  $sql="CALL Userinfo('".$id."')";
  $stmt = mysqli_query($conn,$sql) or die (mysqli_error($conn));
      while($row=mysqli_fetch_array($stmt))
      {
          echo $row[0];?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php
          echo $row[1];
      }
       

?>
    
    </body>
</html>